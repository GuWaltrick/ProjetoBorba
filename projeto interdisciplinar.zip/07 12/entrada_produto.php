<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
include 'conexao.php';

// Função para entrada manual de produtos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = $_POST['produto_id'];
    $quantidade = $_POST['quantidade'];
    $almoxarifado_id = $_POST['almoxarifado_id'];
    $observacao = $_POST['observacao'];
    $data_validade = $_POST['data_validade'];
    $numero_lote = $_POST['lote'];

    // Inserir ou obter o ID do lote
    $sql_lote = "INSERT INTO lotes (produto_id, numero_lote, data_validade, quantidade) 
                 VALUES (?, ?, ?, ?) 
                 ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade), id = LAST_INSERT_ID(id)";
    $stmt_lote = $conn->prepare($sql_lote);

    if (!$stmt_lote) {
        die("Erro ao preparar a consulta de lote: " . $conn->error);
    }

    $stmt_lote->bind_param("issi", $produto_id, $numero_lote, $data_validade, $quantidade);
    if (!$stmt_lote->execute()) {
        die("Erro ao executar a consulta de lote: " . $stmt_lote->error);
    }

    $lote_id = $stmt_lote->insert_id; // Obter o ID do lote inserido ou atualizado

    // Inserir ou atualizar estoque
    $sql_estoque = "INSERT INTO estoque (produto_id, localizacao_id, quantidade, data_validade, lote) 
                    VALUES (?, ?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)";
    $stmt_estoque = $conn->prepare($sql_estoque);

    if (!$stmt_estoque) {
        die("Erro ao preparar a consulta de estoque: " . $conn->error);
    }

    $stmt_estoque->bind_param("iiiss", $produto_id, $almoxarifado_id, $quantidade, $data_validade, $numero_lote);
    if (!$stmt_estoque->execute()) {
        die("Erro ao executar a consulta de estoque: " . $stmt_estoque->error);
    }

    // Registrar movimentação
    $sql_movimentacao = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, usuario, data_movimentacao, estoque_destino_id, observacao, lote_id, data_validade) 
                         VALUES (?, ?, 'entrada', ?, NOW(), ?, ?, ?, ?)";
    $stmt_movimentacao = $conn->prepare($sql_movimentacao);

    if (!$stmt_movimentacao) {
        die("Erro ao preparar a consulta de movimentação: " . $conn->error);
    }

    $stmt_movimentacao->bind_param("iiisiss", $produto_id, $quantidade, $_SESSION['usuario']['id'], $almoxarifado_id, $observacao, $lote_id, $data_validade);
    if (!$stmt_movimentacao->execute()) {
        die("Erro ao executar a consulta de movimentação: " . $stmt_movimentacao->error);
    }

    echo "<div class='success'>Produto adicionado ao estoque com sucesso.</div>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Entrada Manual de Produto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Entrada Manual de Produto</h1>
        <form method="POST">
            <label for="produto_id">ID do Produto:</label>
            <input type="number" id="produto_id" name="produto_id" required>
            <label for="quantidade">Quantidade:</label>
            <input type="number" id="quantidade" name="quantidade" required>
            <label for="almoxarifado_id">Almoxarifado:</label>
            <select id="almoxarifado_id" name="almoxarifado_id" required>
                <option value="1">Principal</option>
            </select>
            <label for="data_validade">Data de Validade:</label>
            <input type="date" id="data_validade" name="data_validade" required>
            <label for="lote">Número do Lote:</label>
            <input type="text" id="lote" name="lote" required placeholder="Ex: LOTE12345">
            <label for="observacao">Observação:</label>
            <input type="text" id="observacao" name="observacao">
            <button type="submit">Confirmar</button>
        </form>
    </div>
</body>
</html>
