<?php
include 'conexao.php'; // Inclua sua conexão com o banco

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['solicitacoes'])) {
    // Receber as solicitações selecionadas
    $solicitacoes = $_POST['solicitacoes'];

    foreach ($solicitacoes as $solicitacao_id) {
        // Buscar os dados da solicitação
        $sql = "SELECT s.*, p.nome AS produto, s.quantidade_enviada AS qtd_enviada
                FROM solicitacoes s
                JOIN produtos p ON s.produto_id = p.id
                WHERE s.id = $solicitacao_id AND s.status = 'em_transito'";
        $result = $conn->query($sql);
        $solicitacao = $result->fetch_assoc();

        if ($solicitacao) {
            $produto_id = $solicitacao['produto_id'];
            $quantidade = $solicitacao['qtd_enviada'];
            $almoxarifado_destino = $solicitacao['almoxarifado_destino'];

            // Atualizar o status da solicitação para 'concluida'
            $sql_update = "UPDATE solicitacoes
                           SET status = 'concluida'
                           WHERE id = $solicitacao_id";
            $conn->query($sql_update);

            // Atualizar o estoque de destino (incrementar quantidade)
            $sql_adicionar_estoque = "UPDATE estoque
                                       SET quantidade = quantidade + $quantidade
                                       WHERE produto_id = $produto_id AND localizacao_id = $almoxarifado_destino";
            $conn->query($sql_adicionar_estoque);

            // Caso o produto ainda não exista no estoque de destino, insira
            if ($conn->affected_rows === 0) {
                $sql_inserir_estoque = "INSERT INTO estoque (produto_id, localizacao_id, quantidade)
                                        VALUES ($produto_id, $almoxarifado_destino, $quantidade)";
                $conn->query($sql_inserir_estoque);
            }
        }
    }

    echo "As entradas foram confirmadas com sucesso!";
    echo "<br><a href='entrada_produtos.php'>Voltar</a>";
} else {
    echo "Nenhuma solicitação foi selecionada.";
    echo "<br><a href='entrada_produtos.php'>Voltar</a>";
}
?>

