<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];

    $sql = "INSERT INTO almoxarifados (nome) VALUES ('$nome')";
    if ($conn->query($sql) === TRUE) {
        echo "Almoxarifado cadastrado com sucesso.";
    } else {
        echo "Erro ao cadastrar almoxarifado: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Almoxarifado</title>
</head>
<body>
    <h1>Cadastrar Almoxarifado</h1>
    <form method="POST">
        <label for="nome">Nome do Almoxarifado:</label>
        <input type="text" name="nome" required>
        <button type="submit">Cadastrar</button>
    </form>
</body>
</html>
