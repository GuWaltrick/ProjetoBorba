<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include 'conexao.php';

// Habilitar a exibição de erros para ajudar a identificar problemas
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Função para gerar o número da Nota Fiscal (NF)
function gerarNumeroNF($conn) {
    $nf_sql = "SELECT MAX(numero_nf) AS max_nf FROM notas_fiscais";
    $nf_result = $conn->query($nf_sql);
    $nf_row = $nf_result->fetch_assoc();
    $novo_nf = $nf_row['max_nf'] + 1;

    $insere_nf_sql = "INSERT INTO notas_fiscais (numero_nf) VALUES ($novo_nf)";
    $conn->query($insere_nf_sql);
    return str_pad($novo_nf, 5, '0', STR_PAD_LEFT);
}

// Processamento da saída de produtos do estoque principal para os almoxarifados
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['transferir'])) {
    $almoxarifado_destino_id = $_POST['almoxarifado_destino_id'];
    $observacao = isset($_POST['observacao']) ? $_POST['observacao'] : '';

    if ($almoxarifado_destino_id == 1) {
        echo "<div class='error'>O estoque de destino não pode ser o estoque principal.</div>";
    } else {
        $numero_nf = gerarNumeroNF($conn);

        foreach ($_POST['produtos'] as $produto) {
            $produto_id = $produto['id'];
            $quantidade = $produto['quantidade'];

            // Verificação de quantidade no estoque principal
            $verifica_sql = "SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = 1";
            $verifica_result = $conn->query($verifica_sql);
            $row = $verifica_result->fetch_assoc();

            if ($row && $row['quantidade'] >= $quantidade) {
                // Atualização do estoque principal (saída)
                $conn->query("UPDATE estoque SET quantidade = quantidade - $quantidade WHERE produto_id = $produto_id AND localizacao_id = 1");

                // Inserir transferência pendente na tabela de transferências
                $conn->query("INSERT INTO transferencias (produto_id, quantidade, tipo, data_transferencia, almoxarifado_origem, almoxarifado_destino) VALUES ($produto_id, $quantidade, 'saida', NOW(), 1, $almoxarifado_destino_id)");

                // Registrar movimentação da saída
                $conn->query("INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf, estoque_origem_id, estoque_destino_id) VALUES ($produto_id, $quantidade, 'NF Saída', 'Transferência para almoxarifado - $observacao', '{$_SESSION['usuario']}', NOW(), '$numero_nf', 1, $almoxarifado_destino_id)");

                echo "<div class='success'>Saída registrada com sucesso! Nota Fiscal: NF-$numero_nf. Aguardando confirmação de entrada no almoxarifado.</div>";
            } else {
                echo "<div class='error'>Quantidade insuficiente para o produto ID $produto_id no estoque principal.</div>";
            }
        }
    }
}

// Confirmação da entrada de produtos no almoxarifado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmar_entrada'])) {
    $transferencia_id = $_POST['transferencia_id'];

    // Buscar informações da transferência
    $transferencia_sql = "SELECT * FROM transferencias WHERE id = $transferencia_id AND tipo = 'saida'";
    $transferencia_result = $conn->query($transferencia_sql);
    $transferencia = $transferencia_result->fetch_assoc();

    if ($transferencia) {
        $produto_id = $transferencia['produto_id'];
        $quantidade = $transferencia['quantidade'];
        $almoxarifado_destino_id = $transferencia['almoxarifado_destino'];

        // Atualizar o estoque do almoxarifado destino (entrada)
        $verifica_destino_sql = "SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = $almoxarifado_destino_id";
        $verifica_destino_result = $conn->query($verifica_destino_sql);

        if ($verifica_destino_result && $verifica_destino_result->num_rows > 0) {
            $conn->query("UPDATE estoque SET quantidade = quantidade + $quantidade WHERE produto_id = $produto_id AND localizacao_id = $almoxarifado_destino_id");
        } else {
            $conn->query("INSERT INTO estoque (produto_id, localizacao_id, quantidade) VALUES ($produto_id, $almoxarifado_destino_id, $quantidade)");
        }

        // Atualizar o tipo de transferência para 'entrada'
        $conn->query("UPDATE transferencias SET tipo = 'entrada' WHERE id = $transferencia_id");

        // Registrar movimentação da entrada
        $conn->query("INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf, estoque_origem_id, estoque_destino_id) VALUES ($produto_id, $quantidade, 'NF Entrada', 'Recebido de Transferência', '{$_SESSION['usuario']}', NOW(), '{$transferencia['numero_nf']}', 1, $almoxarifado_destino_id)");

        echo "<div class='success'>Entrada confirmada com sucesso no almoxarifado destino.</div>";
    } else {
        echo "<div class='error'>Erro ao confirmar a entrada da transferência.</div>";
    }
}

// Carregamento de produtos e estoques
$produto_sql = "SELECT id, nome FROM produtos";
$produtos_result = $conn->query($produto_sql);

$estoques_sql = "SELECT id, descricao FROM localizacao WHERE id != 1"; // Exclui o estoque principal
$estoques_result = $conn->query($estoques_sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Saída de Produtos - Estoque Principal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Saída de Produtos - Estoque Principal</h1>

        <!-- Formulário de Transferência -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="almoxarifado_destino_id">Almoxarifado de Destino:</label>
                <select id="almoxarifado_destino_id" name="almoxarifado_destino_id" required>
                    <option value="">Selecione o almoxarifado de destino</option>
                    <?php while ($row = $estoques_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['descricao']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="observacao">Observação (opcional):</label>
                <input type="text" id="observacao" name="observacao">
            </div>

            <h2>Produtos para Transferência</h2>
            <div id="produtos-selecionados"></div>
            <button type="button" onclick="adicionarProduto()">Adicionar Produto</button>

            <div class="form-buttons">
                <button type="submit" name="transferir">Confirmar Saída</button>
            </div>
        </form>

        <h2>Confirmação de Entradas Pendentes</h2>
        <!-- Formulário de Confirmação de Entrada -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="transferencia_id">Transferência Pendente:</label>
                <select id="transferencia_id" name="transferencia_id" required>
                    <option value="">Selecione uma transferência pendente</option>
                    <?php
                    $pendentes_sql = "SELECT t.id, p.nome, t.quantidade, l.descricao FROM transferencias t JOIN produtos p ON t.produto_id = p.id JOIN localizacao l ON t.almoxarifado_destino = l.id WHERE t.tipo = 'saida'";
                    $pendentes_result = $conn->query($pendentes_sql);
                    while ($row = $pendentes_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>">
                            <?php echo "Produto: " . $row['nome'] . " - Quantidade: " . $row['quantidade'] . " - Destino: " . $row['descricao']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-buttons">
                <button type="submit" name="confirmar_entrada">Confirmar Entrada</button>
            </div>
        </form>
    </div>

    <script>
        const produtosDisponiveis = <?php echo json_encode($produtos_result->fetch_all(MYSQLI_ASSOC)); ?>;
        let produtoIndex = 0;

        function adicionarProduto() {
            const produtoContainer = document.createElement("div");
            produtoContainer.classList.add("produto-container");

            const produtoSelect = document.createElement("select");
            produtoSelect.name = `produtos[${produtoIndex}][id]`;
            produtoSelect.required = true;
            produtoSelect.innerHTML = '<option value="">Selecione um produto</option>';
            produtosDisponiveis.forEach(produto => {
                produtoSelect.innerHTML += `<option value="${produto.id}">${produto.nome}</option>`;
            });

            const quantidadeInput = document.createElement("input");
            quantidadeInput.type = "number";
            quantidadeInput.name = `produtos[${produtoIndex}][quantidade]`;
            quantidadeInput.min = 1;
            quantidadeInput.placeholder = "Quantidade";
            quantidadeInput.required = true;

            produtoContainer.appendChild(produtoSelect);
            produtoContainer.appendChild(quantidadeInput);
            document.getElementById("produtos-selecionados").appendChild(produtoContainer);

            produtoIndex++;
        }
    </script>
</body>
</html>
