<?php

// Incluir o arquivo de conexão com o banco de dados
include 'conexao.php';

// Exibir erros de PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar buffer de saída
ob_start();

// Verificar se o formulário foi enviado (solicitação de confirmação de entrada)
if (isset($_POST['confirmar_entrada'])) {
    // Capturar os dados da solicitação
    $solicitacao_id = $_POST['solicitacao_id'];

    if (!$solicitacao_id) {
        echo "ID da solicitação não fornecido.";
        exit;
    }

    // Buscar as informações da solicitação pendente no banco de dados
    $query_solicitacao = "SELECT produto_id, quantidade, almoxarifado_origem, almoxarifado_destino, status FROM solicitacoes WHERE id = ?";
    $stmt = $conn->prepare($query_solicitacao);
    $stmt->bind_param('i', $solicitacao_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        // Extrair os dados da solicitação
        $solicitacao = $resultado->fetch_assoc();
        $produto_id = $solicitacao['produto_id'];
        $quantidade = $solicitacao['quantidade'];
        $almoxarifado_origem = $solicitacao['almoxarifado_origem'];
        $almoxarifado_destino = $solicitacao['almoxarifado_destino'];
        $status_atual = $solicitacao['status'];

        if ($status_atual == 'concluida') {
            echo "Esta solicitação já foi concluída.";
            exit;
        }

        // Iniciar uma transação para garantir a consistência dos dados
        $conn->begin_transaction();

        try {
            // Diminuir a quantidade do produto no almoxarifado remetente (origem)
            $query_atualizar_estoque_origem = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto_id = ? AND localizacao_id = ?";
            $stmt_atualizar_origem = $conn->prepare($query_atualizar_estoque_origem);
            if ($stmt_atualizar_origem === false) {
                throw new Exception("Erro na preparação da consulta de atualização do estoque de origem: " . $conn->error);
            }
            $stmt_atualizar_origem->bind_param('iii', $quantidade, $produto_id, $almoxarifado_origem);
            $stmt_atualizar_origem->execute();

            if ($stmt_atualizar_origem->affected_rows <= 0) {
                throw new Exception("Erro ao diminuir a quantidade no estoque do almoxarifado de origem. Verifique se a quantidade disponível é suficiente.");
            }

            // Aumentar a quantidade do produto no almoxarifado destinatário (destino)
            $query_atualizar_estoque_destino = "INSERT INTO estoque (produto_id, localizacao_id, quantidade) VALUES (?, ?, ?) 
                                                ON DUPLICATE KEY UPDATE quantidade = quantidade + ?";
            $stmt_atualizar_destino = $conn->prepare($query_atualizar_estoque_destino);
            if ($stmt_atualizar_destino === false) {
                throw new Exception("Erro na preparação da consulta de atualização do estoque de destino: " . $conn->error);
            }

            $stmt_atualizar_destino->bind_param('iiii', $produto_id, $almoxarifado_destino, $quantidade, $quantidade);
            $stmt_atualizar_destino->execute();

            if ($stmt_atualizar_destino->affected_rows >= 0) {
                // Atualizar o status da solicitação para 'concluída'
                $query_atualizar_status = "UPDATE solicitacoes SET status = 'concluida' WHERE id = ? AND status != 'concluida'";
                $stmt_status = $conn->prepare($query_atualizar_status);
                if ($stmt_status === false) {
                    throw new Exception("Erro na preparação da consulta de atualização do status da solicitação: " . $conn->error);
                }

                $stmt_status->bind_param('i', $solicitacao_id);
                $stmt_status->execute();

                if ($stmt_status->affected_rows > 0) {
                    echo "Status da solicitação atualizado para 'concluída'.<br>";
                } else {
                    echo "Falha ao atualizar o status da solicitação. Verifique se o status já foi atualizado.<br>";
                }

                // Confirmar a transação
                $conn->commit();
                echo "Solicitação confirmada e estoque atualizado com sucesso.";
                
                // Redirecionar para a página de consulta do estoque
                ob_end_flush(); // Finalizar buffer de saída
                header("Location: consulta_estoque.php");
                exit();
            } else {
                throw new Exception("Erro ao atualizar a quantidade no estoque do almoxarifado de destino.");
            }

        } catch (Exception $e) {
            // Reverter a transação em caso de erro
            $conn->rollback();
            echo "Erro ao processar a solicitação: " . $e->getMessage();
        }

        // Fechar as declarações preparadas
        $stmt_atualizar_origem->close();
        $stmt_atualizar_destino->close();
        $stmt_status->close();

    } else {
        echo "Solicitação não encontrada ou ID incorreto.";
    }

    // Fechar a consulta de solicitação
    $stmt->close();
} else {
    echo "Nenhuma solicitação foi enviada.";
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
