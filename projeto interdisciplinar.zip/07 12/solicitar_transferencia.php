
<?php
include 'conexao.php'; // Inclui a conexão com o banco de dados

// Consultar os produtos e suas quantidades no banco de dados, considerando o estoque em diferentes localizações
$sql_produtos = "
    SELECT 
        p.id, 
        p.nome, 
        COALESCE(SUM(CASE WHEN e.localizacao_id = 1 THEN e.quantidade ELSE 0 END), 0) AS estoque_principal,
        COALESCE(SUM(CASE WHEN e.localizacao_id = 2 THEN e.quantidade ELSE 0 END), 0) AS almoxarifado_1,
        COALESCE(SUM(CASE WHEN e.localizacao_id = 3 THEN e.quantidade ELSE 0 END), 0) AS almoxarifado_2
    FROM produtos p
    LEFT JOIN estoque e ON p.id = e.produto_id
    GROUP BY p.id, p.nome
";
$result_produtos = $conn->query($sql_produtos);

// Consultar os almoxarifados disponíveis
$sql_almoxarifados = "SELECT id, descricao FROM localizacao";
$result_almoxarifados = $conn->query($sql_almoxarifados);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $almoxarifado_destino = $_POST['almoxarifado_destino'];
    $almoxarifado_origem = $_POST['almoxarifado_origem'];

    if (isset($_POST['produtos_selecionados']) && !empty($_POST['produtos_selecionados'])) {
        // Criar uma solicitação única para vários produtos
        foreach ($_POST['produtos_selecionados'] as $produto_id) {
            $quantidade = $_POST['quantidade_' . $produto_id];

            // Verifica se a quantidade foi especificada e é maior que zero
            if ($quantidade > 0) {
                // Inserir a solicitação de transferência para cada produto selecionado
                $sql = "INSERT INTO solicitacoes (produto_id, quantidade, almoxarifado_origem, almoxarifado_destino)
                        VALUES ($produto_id, $quantidade, $almoxarifado_origem, $almoxarifado_destino)";

                if ($conn->query($sql)) {
                    echo "Produto ID $produto_id: Solicitação de transferência criada com sucesso.<br>";
                } else {
                    echo "Erro ao criar solicitação para o produto ID $produto_id: " . $conn->error . "<br>";
                }
            } else {
                echo "Erro: Quantidade para o produto ID $produto_id não foi especificada corretamente.<br>";
            }
        }
    } else {
        echo "Nenhum produto foi selecionado para transferência.<br>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Transferência de Produtos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eaf0f6;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 90%;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #007bff;
        }
        .search-bar {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 1em;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 20px auto;
        }
        button:hover {
            background-color: #218838;
        }
        select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
        }
        input[type="number"] {
            width: 80px; /* Define um tamanho fixo para os campos de quantidade */
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            text-align: center;
        }
    </style>
    <script>
        function filterProducts() {
            let searchValue = document.getElementById('productSearch').value.toLowerCase();
            let rows = document.querySelectorAll('table tbody tr');
            rows.forEach(row => {
                let productName = row.cells[2].textContent.toLowerCase();
                let productId = row.cells[1].textContent.toLowerCase();
                if (productName.includes(searchValue) || productId.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function toggleQuantityRequirement(checkbox, productId) {
            let quantityInput = document.getElementById('quantidade_' + productId);
            if (checkbox.checked) {
                quantityInput.required = true;
            } else {
                quantityInput.required = false;
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Solicitar Transferência de Produtos</h1>

        <!-- Barra de busca para filtrar os produtos -->
        <input type="text" id="productSearch" class="search-bar" onkeyup="filterProducts()" placeholder="Digite o nome ou ID do produto para buscar...">

        <form method="POST" action="">
            <label for="almoxarifado_origem">Almoxarifado de Origem:</label>
            <select name="almoxarifado_origem" id="almoxarifado_origem" required>
                <option value="" disabled selected>Selecione um almoxarifado de origem</option>
                <?php
                $result_almoxarifados->data_seek(0); // Reutilizar a lista de almoxarifados
                while ($almoxarifado = $result_almoxarifados->fetch_assoc()): ?>
                    <option value="<?= $almoxarifado['id'] ?>"><?= $almoxarifado['descricao'] ?></option>
                <?php endwhile; ?>
            </select>
            <br><br>

            <label for="almoxarifado_destino">Almoxarifado de Destino:</label>
            <select name="almoxarifado_destino" id="almoxarifado_destino" required>
                <option value="" disabled selected>Selecione um almoxarifado de destino</option>
                <?php
                $result_almoxarifados->data_seek(0); // Reutilizar a lista de almoxarifados
                while ($almoxarifado = $result_almoxarifados->fetch_assoc()): ?>
                    <option value="<?= $almoxarifado['id'] ?>"><?= $almoxarifado['descricao'] ?></option>
                <?php endwhile; ?>
            </select>
            <br><br>

            <table>
                <thead>
                    <tr>
                        <th>Selecionar</th>
                        <th>ID</th>
                        <th>Produto</th>
                        <th>Estoque Principal</th>
                        <th>Almoxarifado 1</th>
                        <th>Almoxarifado 2</th>
                        <th>Quantidade a Transferir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_produtos && $result_produtos->num_rows > 0): ?>
                        <?php while ($produto = $result_produtos->fetch_assoc()): ?>
                            <tr>
                                <td><input type="checkbox" name="produtos_selecionados[]" value="<?= htmlspecialchars($produto['id']) ?>" onchange="toggleQuantityRequirement(this, <?= htmlspecialchars($produto['id']) ?>)"></td>
                                <td><?= htmlspecialchars($produto['id']) ?></td>
                                <td><?= htmlspecialchars($produto['nome']) ?></td>
                                <td><?= htmlspecialchars($produto['estoque_principal']) ?></td>
                                <td><?= htmlspecialchars($produto['almoxarifado_1']) ?></td>
                                <td><?= htmlspecialchars($produto['almoxarifado_2']) ?></td>
                                <td><input type="number" id="quantidade_<?= htmlspecialchars($produto['id']) ?>" name="quantidade_<?= htmlspecialchars($produto['id']) ?>" min="1" max="<?= htmlspecialchars($produto['estoque_principal'] + $produto['almoxarifado_1'] + $produto['almoxarifado_2']) ?>"></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7">Nenhum produto disponível encontrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit">Solicitar Transferência</button>
        </form>
    </div>
</body>
</html>