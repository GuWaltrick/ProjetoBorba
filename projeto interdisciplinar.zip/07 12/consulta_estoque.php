<?php
// Inicie a sessão e conecte ao banco de dados
session_start();
include('conexao.php'); // Inclua o arquivo de conexão com o banco de dados

// Defina variáveis para os filtros
$categoria = '';
$fornecedor = '';
$status = '';

// Verifique se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoria = $_POST['categoria'];
    $fornecedor = $_POST['fornecedor'];
    $status = $_POST['status'];
}

// Consultar produtos com base nos filtros
$query = "SELECT * FROM produtos WHERE 1=1"; // 1=1 para facilitar a adição de condições

if ($categoria) {
    $query .= " AND categoria = '$categoria'";
}
if ($fornecedor) {
    $query .= " AND fornecedor = '$fornecedor'";
}
if ($status) {
    $query .= " AND status = '$status'";
}

$resultado = mysqli_query($conexao, $query);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Estoque</title>
    <link rel="stylesheet" href="styles.css"> <!-- Inclua seu arquivo de estilos -->
</head>
<body>
    <div class="container">
        <h1>Consulta de Estoque</h1>
        <form method="POST" action="">
            <label for="categoria">Categoria:</label>
            <input type="text" name="categoria" id="categoria" value="<?= $categoria ?>">

            <label for="fornecedor">Fornecedor:</label>
            <input type="text" name="fornecedor" id="fornecedor" value="<?= $fornecedor ?>">

            <label for="status">Status:</label>
            <select name="status" id="status">
                <option value="">Selecione</option>
                <option value="Baixa" <?= $status == 'Baixa' ? 'selected' : '' ?>>Baixa</option>
                <option value="Alta" <?= $status == 'Alta' ? 'selected' : '' ?>>Alta</option>
            </select>

            <input type="submit" value="Consultar">
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Preço</th>
                    <th>Quantidade</th>
                    <th>Categoria</th>
                    <th>Fornecedor</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($produto = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?= $produto['id'] ?></td>
                    <td><?= $produto['nome'] ?></td>
                    <td><?= $produto['descricao'] ?></td>
                    <td><?= $produto['preco'] ?></td>
                    <td><?= $produto['quantidade'] ?></td>
                    <td><?= $produto['categoria'] ?></td>
                    <td><?= $produto['fornecedor'] ?></td>
                    <td><?= $produto['status'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
