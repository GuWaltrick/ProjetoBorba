/* Estilo para o fundo da página */
body {
    background-color: #eef0e5; /* Usando $color-green-background */
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

/* Estilo do container principal */
.container {
    width: 80%;
    margin: 0 auto;
    background-color: #f2f4f2; /* Usando $color-light-gray */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

/* Estilo para os títulos */
h1 {
    color: #00a32a; /* Usando $color-green */
    text-align: center;
}

/* Estilo dos botões */
button, input[type="submit"] {
    background-color: #00a32a; /* Usando $color-green */
    color: #fff; /* Branco para contraste */
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

button:hover, input[type="submit"]:hover {
    background-color: #007b1f; /* Um verde mais escuro ao passar o mouse */
}

/* Estilo dos inputs */
input[type="text"], input[type="number"], textarea, select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #bdbdbd; /* Usando $color-medium-gray */
    border-radius: 5px;
    transition: border-color 0.3s ease;
    background-color: #f2f4f2; /* Usando $color-light-gray */
}

input[type="text"]:focus, input[type="number"]:focus, textarea:focus, select:focus {
    border-color: #00a32a; /* Usando $color-green */
}

/* Estilo da tabela */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

table, th, td {
    border: 1px solid #bdbdbd; /* Usando $color-medium-gray */
}

th, td {
    padding: 15px;
    text-align: left;
}

th {
    background-color: #00a32a; /* Usando $color-green */
    color: white;
}

tr:nth-child(even) {
    background-color: #f2f4f2; /* Usando $color-light-gray */
}

.alert {
    color: red; /* Cor do texto do alerta */
    margin: 10px 0; /* Margem em cima e embaixo */
    text-align: center; /* Centraliza o texto */
}

/* Estilo para o fundo da página de dashboard */
.dashboard {
    background-color: #eef0e5; /* Usando $color-green-background */
    padding: 20px; /* Para adicionar um pouco de espaçamento */
    border-radius: 10px; /* Bordas arredondadas */
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* Sombra para dar profundidade */
}

/* Estilo para os títulos na dashboard */
.dashboard h1 {
    color: #00a32a; /* Usando $color-green */
    text-align: center;
}

/* Estilo para os links como botões */
.buttons {
    text-align: center; /* Centraliza os botões */
    margin-top: 20px; /* Espaço acima dos botões */
}

.button {
    display: inline-block; /* Faz os links se comportarem como botões */
    background-color: #00a32a; /* Usando $color-green */
    color: white; /* Branco para contraste */
    padding: 10px 20px; /* Espaçamento interno */
    margin: 10px; /* Espaço entre os botões */
    text-decoration: none; /* Remove o sublinhado */
    border-radius: 5px; /* Bordas arredondadas */
    transition: background-color 0.3s ease; /* Transição suave na mudança de cor */
}

.button:hover {
    background-color: #007b1f; /* Verde mais escuro ao passar o mouse */
}

/* Estilo para a container dos botões */
.button-container {
    display: flex; /* Usando flexbox para alinhar as caixas */
    justify-content: center; /* Centraliza as caixas */
    margin-top: 20px; /* Espaçamento acima das caixas */
}

.button-box {
    margin: 10px; /* Espaçamento entre as caixas */
    padding: 20px; /* Espaçamento interno das caixas */
    border: 1px solid #bdbdbd; /* Borda para as caixas */
    border-radius: 10px; /* Bordas arredondadas */
    background-color: #f2f4f2; /* Fundo claro para as caixas */
    text-align: center; /* Centraliza o texto dentro das caixas */
}

/* Estilo para o botão Sair */
.logout-button {
    position: absolute; /* Para posicionar no canto inferior direito */
    bottom: 20px; /* Espaçamento do fundo */
    right: 20px; /* Espaçamento da direita */
    background-color: #d9534f; /* Vermelho para destaque */
    color: white; /* Cor do texto */
    padding: 10px 20px; /* Espaçamento interno */
    text-decoration: none; /* Remove sublinhado */
    border-radius: 5px; /* Bordas arredondadas */
    transition: background-color 0.3s ease; /* Transição suave */
}

.logout-button:hover {
    background-color: #c9302c; /* Vermelho mais escuro ao passar o mouse */
}

/* Estilo para o botão de perfil no canto superior direito */
.user-profile {
    position: absolute;
    top: 20px; /* Define a posição no topo */
    right: 20px; /* Define a posição à direita */
}

.profile-button {
    background-color: #00a32a; /* Cor verde */
    color: white; /* Cor do texto (branco) */
    border-radius: 50%; /* Faz o botão ficar redondo */
    width: 50px; /* Define a largura do botão */
    height: 50px; /* Define a altura do botão */
    display: flex; /* Alinhamento dos elementos dentro do botão */
    align-items: center;
    justify-content: center;
    cursor: pointer; /* Muda o cursor para indicar um botão */
    position: relative;
}

.profile-dropdown {
    display: none; /* Esconde o menu de logout inicialmente */
    position: absolute;
    top: 60px;
    right: 0;
    background-color: white;
    border: 1px solid #bdbdbd;
    border-radius: 5px;
    padding: 10px;
}

.profile-button:hover .profile-dropdown {
    display: block; /* Mostra o menu ao passar o mouse */
}

.profile-dropdown a {
    text-decoration: none; /* Remove o sublinhado do link */
    color: red; /* Cor vermelha para o botão de sair */
    display: block;
    padding: 5px;
}

.profile-dropdown a:hover {
    background-color: #f2f2f2; /* Fundo cinza ao passar o mouse */
}

