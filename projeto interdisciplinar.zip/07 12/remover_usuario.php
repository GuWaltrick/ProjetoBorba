<?php
session_start();

// Verifica se o usuário é administrador
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['tipo'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Verifica se o ID do usuário foi fornecido na URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID do usuário não fornecido.";
    exit();
}

$usuarioId = intval($_GET['id']); // Sanitiza o ID

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "estoque");
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Exclui o usuário do banco de dados
$stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuarioId);

if ($stmt->execute()) {
    echo "<script>alert('Usuário removido com sucesso!'); window.location.href='cadastrar_usuario.php';</script>";
} else {
    echo "Erro ao remover usuário: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
