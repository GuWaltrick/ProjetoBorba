<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['tipo'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$produto_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $lote = $_POST['lote'];
    $data_validade = $_POST['data_validade'];
    $fornecedor = $_POST['fornecedor'];

    $sql_update = "UPDATE produtos SET nome = ?, descricao = ?, preco = ?, lote = ?, data_validade = ?, fornecedor = ? WHERE id = ?";
    $stmt = $conn->prepare($sql_update);
    $stmt->bind_param("ssdsssi", $nome, $descricao, $preco, $lote, $data_validade, $fornecedor, $produto_id);

    if ($stmt->execute()) {
        header("Location: ver_produtos.php?mensagem=Produto atualizado com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar o produto: " . $conn->error;
    }
} else {
    $sql_produto = "SELECT * FROM produtos WHERE id = ?";
    $stmt = $conn->prepare($sql_produto);
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();
    if (!$produto) {
        echo "Produto não encontrado.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
</head>
<body>
    <h1>Editar Produto</h1>
    <form method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required><br>

        <label for="descricao">Descrição:</label>
        <input type="text" name="descricao" value="<?= htmlspecialchars($produto['descricao']) ?>" required><br>

        <label for="preco">Preço:</label>
        <input type="number" step="0.01" name="preco" value="<?= htmlspecialchars($produto['preco']) ?>" required><br>

        <label for="lote">Lote:</label>
        <input type="text" name="lote" value="<?= htmlspecialchars($produto['lote']) ?>" required><br>

        <label for="data_validade">Data de Validade:</label>
        <input type="date" name="data_validade" value="<?= htmlspecialchars($produto['data_validade']) ?>" required><br>

        <label for="fornecedor">Fornecedor:</label>
        <input type="text" name="fornecedor" value="<?= htmlspecialchars($produto['fornecedor']) ?>" required><br>

        <button type="submit">Salvar</button>
    </form>
</body>
</html>
