<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos Vencidos</title>
    <link rel="stylesheet" type="text/css" href="styles.css"> <!-- Certifique-se de ter este arquivo -->
</head>
<body>
    <h1>Lista de Produtos Vencidos</h1>

    <?php
    // Consulta para obter produtos vencidos
    $sql = "SELECT * FROM produtos_vencidos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table border='1'>
                <tr>
                    <th>ID</th>
                    <th>Nome do Produto</th>
                    <th>Lote</th>
                    <th>Quantidade</th>
                    <th>Data de Vencimento</th>
                    <th>Data de Registro</th>
                </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nome_produto']}</td>
                    <td>{$row['lote']}</td>
                    <td>{$row['quantidade']}</td>
                    <td>{$row['data_vencimento']}</td>
                    <td>{$row['data_registro']}</td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "Nenhum produto vencido encontrado.";
    }

    $conn->close(); // Fechando a conexão
    ?>
</body>
</html>
