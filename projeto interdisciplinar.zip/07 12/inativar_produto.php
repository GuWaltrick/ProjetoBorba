<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['tipo'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$produto_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql_inativar = "UPDATE produtos SET ativo = 0 WHERE id = ?";
$stmt = $conn->prepare($sql_inativar);
$stmt->bind_param("i", $produto_id);

if ($stmt->execute()) {
    header("Location: ver_produtos.php?mensagem=Produto inativado com sucesso");
    exit();
} else {
    echo "Erro ao inativar o produto: " . $conn->error;
}
?>
