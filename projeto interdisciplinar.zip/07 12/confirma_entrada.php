<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['confirmar_entrada']) && isset($_POST['solicitacoes_entrada'])) {
    $solicitacoes_entrada = $_POST['solicitacoes_entrada'];

    foreach ($solicitacoes_entrada as $solicitacao_id) {
        // Atualizar o status da solicitação para 'concluida'
        $query_update_status = "UPDATE solicitacoes SET status = 'concluida' WHERE id = ?";
        $stmt_status = $conn->prepare($query_update_status);
        $stmt_status->bind_param('i', $solicitacao_id);
        $stmt_status->execute();
        $stmt_status->close();

        // Buscar a solicitação para obter os dados necessários
        $query_solicitacao = "SELECT produto_id, quantidade, almoxarifado_destino FROM solicitacoes WHERE id = ?";
        $stmt_solicitacao = $conn->prepare($query_solicitacao);
        $stmt_solicitacao->bind_param('i', $solicitacao_id);
        $stmt_solicitacao->execute();
        $resultado_solicitacao = $stmt_solicitacao->get_result();

        if ($resultado_solicitacao->num_rows > 0) {
            $solicitacao = $resultado_solicitacao->fetch_assoc();
            $produto_id = $solicitacao['produto_id'];
            $quantidade = $solicitacao['quantidade'];
            $almoxarifado_destino = $solicitacao['almoxarifado_destino'];

            // Atualizar o estoque do almoxarifado de destino
            $query_update_estoque = "INSERT INTO estoque (produto_id, localizacao_id, quantidade) VALUES (?, ?, ?)
                                     ON DUPLICATE KEY UPDATE quantidade = quantidade + ?";
            $stmt_estoque = $conn->prepare($query_update_estoque);
            $stmt_estoque->bind_param('iiii', $produto_id, $almoxarifado_destino, $quantidade, $quantidade);
            $stmt_estoque->execute();
            $stmt_estoque->close();

            // Inserir uma movimentação de entrada
            $query_movimentacao = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, estoque_destino_id, usuario, data_movimentacao)
                                   VALUES (?, ?, 'entrada', ?, ?, NOW())";
            $stmt_movimentacao = $conn->prepare($query_movimentacao);
            $stmt_movimentacao->bind_param('iiis', $produto_id, $quantidade, $almoxarifado_destino, $_SESSION['usuario']);
            $stmt_movimentacao->execute();
            $stmt_movimentacao->close();
        }

        $stmt_solicitacao->close();
    }

    echo "Solicitação de entrada confirmada e estoque atualizado com sucesso.";
    header("Location: ver_solicitacoes.php");
    exit();
} else {
    echo "Nenhuma solicitação foi selecionada.";
}
?>
