<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha - Web Estoque</title>
    <link rel="stylesheet" type="text/css" href="styles.php">
    <style>
        /* Estilo para o fundo da página */
        body {
            background-image: url('tela de login.jpg'); /* Define a imagem de fundo */
            background-size: cover; /* Faz a imagem cobrir todo o fundo */
            background-position: center; /* Centraliza a imagem */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Estilo do formulário de recuperação de senha */
        .password-reset-container {
            width: 300px; /* Largura do formulário */
            margin: auto; /* Centraliza o formulário */
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Fundo branco com transparência */
            border-radius: 10px; /* Bordas arredondadas */
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* Sombra para dar profundidade */
            margin-top: 100px; /* Espaço do topo */
        }

        h1 {
            color: #00a32a; /* Usando $color-green */
            text-align: center;
        }

        button, input[type="submit"] {
            background-color: #00a32a; /* Usando $color-green */
            color: #fff; /* Branco para contraste */
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            width: 100%; /* Largura do botão */
        }

        button:hover, input[type="submit"]:hover {
            background-color: #007b1f; /* Um verde mais escuro ao passar o mouse */
        }

        input[type="email"] {
            width: 100%; /* Largura total */
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #bdbdbd; /* Borda cinza */
            border-radius: 5px; /* Bordas arredondadas */
            background-color: #f2f4f2; /* Fundo cinza claro */
        }

        .alert {
            color: red; /* Cor do texto do alerta */
            margin: 10px 0; /* Margem em cima e embaixo */
            text-align: center; /* Centraliza o texto */
        }

        .back-to-login {
            text-align: center;
            margin-top: 10px;
        }

        .back-to-login a {
            color: #00a32a; /* Verde */
            text-decoration: none;
        }

        .back-to-login a:hover {
            text-decoration: underline; /* Sublinhado ao passar o mouse */
        }
    </style>
</head>
<body>
    <div class="password-reset-container">
        <h1>Recuperar Senha</h1>
        <form method="post">
            <label for="email">Digite seu e-mail:</label>
            <input type="email" name="email" required>
            <br>
            <input type="submit" value="Enviar">
        </form>

        <div class="back-to-login">
            <a href="login.php">Voltar para Login</a>
        </div>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'];

            // Simula envio de e-mail de recuperação de senha
            echo "<div class='alert'>Um link de recuperação foi enviado para $email (simulado).</div>";
        }
        ?>
    </div>
</body>
</html>
