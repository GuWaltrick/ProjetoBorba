<?php
require_once 'conexao.php'; // Conexão com o banco

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografa a senha
    $tipo = $_POST['tipo'];
    $estoque = intval($_POST['estoque']); // Estoque ao qual o usuário terá acesso

    // Verifica se o e-mail já está registrado
    $verifica = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $verifica->bind_param("s", $email);
    $verifica->execute();
    $result = $verifica->get_result();

    if ($result->num_rows > 0) {
        echo "E-mail já registrado. Tente outro.";
        exit;
    }

    // Insere o usuário no banco de dados
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, tipo, estoque_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $nome, $email, $senha, $tipo, $estoque);

    if ($stmt->execute()) {
        echo "Usuário cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar usuário.";
    }

    // Fechar as consultas preparadas
    $verifica->close();
    $stmt->close();
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
