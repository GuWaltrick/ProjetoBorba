<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
require_once 'conexao.php';

// Processa a saída de produto para uso interno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registrar_saida'])) {
    $produto_id = $_POST['produto_id'];
    $quantidade = $_POST['quantidade'];
    $motivo = "Uso Interno"; // Motivo fixo para consumo interno
    $usuario = $_SESSION['usuario']['nome'];

    // Verifica quantidade em estoque
    $sql = "SELECT quantidade FROM estoque WHERE produto_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $estoque = $result->fetch_assoc();

    if ($estoque['quantidade'] < $quantidade) {
        echo "<script>alert('Quantidade insuficiente em estoque!');</script>";
    } else {
        // Atualiza a tabela de estoque
        $sql = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $quantidade, $produto_id);
        $stmt->execute();

        // Registra a movimentação
        $sql = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, usuario, motivo, data_movimentacao) 
                VALUES (?, ?, 'saida', ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $produto_id, $quantidade, $usuario, $motivo);
        $stmt->execute();

        echo "<script>alert('Saída para uso interno registrada com sucesso!');</script>";
    }
}

// Busca produtos disponíveis
$sql = "SELECT p.id, p.nome, e.quantidade 
        FROM produtos p 
        JOIN estoque e ON p.id = e.produto_id";
$result = $conn->query($sql);
$produtos = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saída para Uso Interno</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Registrar Saída para Uso Interno</h1>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="produto_id" class="form-label">Produto:</label>
                <select name="produto_id" id="produto_id" class="form-select" required>
                    <option value="">Selecione um produto</option>
                    <?php foreach ($produtos as $produto): ?>
                        <option value="<?= $produto['id'] ?>">
                            <?= $produto['nome'] ?> (Estoque: <?= $produto['quantidade'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="quantidade" class="form-label">Quantidade:</label>
                <input type="number" name="quantidade" id="quantidade" class="form-control" min="1" required>
            </div>
            <button type="submit" name="registrar_saida" class="btn btn-primary w-100">Registrar Saída</button>
        </form>
    </div>
</body>
</html>
