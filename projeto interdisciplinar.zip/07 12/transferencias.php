<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include 'conexao.php';

// Geração da Nota Fiscal (NF)
function gerarNumeroNF($conn) {
    $nf_sql = "SELECT MAX(numero_nf) AS max_nf FROM notas_fiscais";
    $nf_result = $conn->query($nf_sql);
    if ($nf_result && $nf_result->num_rows > 0) {
        $nf_row = $nf_result->fetch_assoc();
        $novo_nf = $nf_row['max_nf'] + 1;
    } else {
        $novo_nf = 1; // Caso não exista nenhum registro, começaremos do 1
    }

    $insere_nf_sql = "INSERT INTO notas_fiscais (numero_nf) VALUES ($novo_nf)";
    $conn->query($insere_nf_sql);
    return str_pad($novo_nf, 5, '0', STR_PAD_LEFT);
}

// Processamento da transferência de múltiplos produtos
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['produtos'])) {
    $estoque_origem_id = $_POST['estoque_origem_id'];
    $estoque_destino_id = $_POST['estoque_destino_id'];
    $observacao = isset($_POST['observacao']) ? $_POST['observacao'] : '';

    if ($estoque_origem_id == $estoque_destino_id) {
        echo "<div class='error'>O estoque de origem e destino não podem ser iguais.</div>";
    } else {
        $numero_nf = gerarNumeroNF($conn);
        $transferencia_realizada = false;

        foreach ($_POST['produtos'] as $produto) {
            $produto_id = $produto['id'];
            $quantidade = $produto['quantidade'];

            // Verificação de quantidade no estoque de origem
            $verifica_sql = "SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = $estoque_origem_id";
            $verifica_result = $conn->query($verifica_sql);

            if ($verifica_result && $verifica_result->num_rows > 0) {
                $row = $verifica_result->fetch_assoc();
                if ($row['quantidade'] >= $quantidade) {
                    // Atualização dos estoques e registro da movimentação
                    $conn->query("UPDATE estoque SET quantidade = quantidade - $quantidade WHERE produto_id = $produto_id AND localizacao_id = $estoque_origem_id");

                    // Atualização do destino ou inserção do produto
                    $verifica_destino = $conn->query("SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = $estoque_destino_id");
                    if ($verifica_destino && $verifica_destino->num_rows > 0) {
                        $conn->query("UPDATE estoque SET quantidade = quantidade + $quantidade WHERE produto_id = $produto_id AND localizacao_id = $estoque_destino_id");
                    } else {
                        $conn->query("INSERT INTO estoque (produto_id, localizacao_id, quantidade) VALUES ($produto_id, $estoque_destino_id, $quantidade)");
                    }

                    // Registros de movimentação
                    $conn->query("INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf, estoque_origem_id, estoque_destino_id) VALUES ($produto_id, $quantidade, 'NF Saída', 'Transferência - $observacao', '{$_SESSION['usuario']}', NOW(), '$numero_nf', $estoque_origem_id, NULL)");
                    $conn->query("INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf, estoque_origem_id, estoque_destino_id) VALUES ($produto_id, $quantidade, 'NF Entrada', 'Recebido de Transferência - $observacao', '{$_SESSION['usuario']}', NOW(), '$numero_nf', NULL, $estoque_destino_id)");

                    $transferencia_realizada = true;
                } else {
                    echo "<div class='error'>Quantidade insuficiente para o produto ID $produto_id no estoque de origem.</div>";
                }
            } else {
                echo "<div class='error'>Produto ID $produto_id não encontrado no estoque de origem.</div>";
            }
        }

        if ($transferencia_realizada) {
            echo "<div class='success'>Transferência realizada com sucesso! Nota Fiscal: NF-$numero_nf</div>";
        }
    }
}

// Carregamento de produtos e estoques
$produto_sql = "SELECT id, nome FROM produtos";
$produtos_result = $conn->query($produto_sql);

$estoques_sql = "SELECT id, descricao FROM localizacao";
$estoques_result = $conn->query($estoques_sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Transferência de Produtos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Transferência de Produtos</h1>

        <form method="POST" action="">
            <div class="form-group">
                <label for="estoque_origem_id">Estoque de Origem:</label>
                <select id="estoque_origem_id" name="estoque_origem_id" required>
                    <option value="">Selecione o estoque de origem</option>
                    <?php while ($row = $estoques_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['descricao']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="estoque_destino_id">Estoque de Destino:</label>
                <select id="estoque_destino_id" name="estoque_destino_id" required>
                    <option value="">Selecione o estoque de destino</option>
                    <?php
                    $estoques_result = $conn->query($estoques_sql);
                    while ($row = $estoques_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['descricao']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="observacao">Observação (opcional):</label>
                <input type="text" id="observacao" name="observacao">
            </div>

            <h2>Produtos para Transferência</h2>
            <div id="produtos-selecionados"></div>
            <button type="button" onclick="adicionarProduto()">Adicionar Produto</button>

            <div class="form-buttons">
                <button type="submit" name="transferir">Confirmar Transferência</button>
            </div>
        </form>
    </div>

    <script>
        const produtosDisponiveis = <?php echo json_encode($produtos_result->fetch_all(MYSQLI_ASSOC)); ?>;
        let produtoIndex = 0;

        function adicionarProduto() {
            const produtoContainer = document.createElement("div");
            produtoContainer.classList.add("produto-container");

            const produtoSelect = document.createElement("select");
            produtoSelect.name = `produtos[${produtoIndex}][id]`;
            produtoSelect.required = true;
            produtoSelect.innerHTML = '<option value="">Selecione um produto</option>';
            produtosDisponiveis.forEach(produto => {
                produtoSelect.innerHTML += `<option value="${produto.id}">${produto.nome}</option>`;
            });

            const quantidadeInput = document.createElement("input");
            quantidadeInput.type = "number";
            quantidadeInput.name = `produtos[${produtoIndex}][quantidade]`;
            quantidadeInput.min = 1;
            quantidadeInput.placeholder = "Quantidade";
            quantidadeInput.required = true;

            produtoContainer.appendChild(produtoSelect);
            produtoContainer.appendChild(quantidadeInput);
            document.getElementById("produtos-selecionados").appendChild(produtoContainer);

            produtoIndex++;
        }
    </script>
</body>
</html>
