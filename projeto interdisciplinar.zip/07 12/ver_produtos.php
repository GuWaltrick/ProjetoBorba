<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Verificar se o usuário é administrador
$usuario_tipo = $_SESSION['usuario']['tipo'] ?? 'user'; // Assumindo que há um campo 'tipo' na sessão que determina o tipo de usuário
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Produtos</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            color: #333;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            color: #28a745;
            text-align: center;
            margin-bottom: 20px;
        }
        .search-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-bar select, .search-bar input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            flex: 1;
        }
        .search-bar button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .search-bar button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background-color: #28a745;
            color: white;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #666;
        }
        .action-button {
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            font-size: 14px;
            display: inline-block;
            margin: 2px;
        }
        .edit-button {
            background-color: #007bff;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
        .inactivate-button {
            background-color: #ffc107;
        }
        .inactivate-button:hover {
            background-color: #e0a800;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
        .usage-button {
            background-color: #28a745;
        }
        .usage-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Lista de Produtos</h1>

        <!-- Barra de Pesquisa -->
        <form method="post" class="search-bar">
            <select name="status">
                <option value="">Filtro por Status</option>
                <option value="alta">Alta de Estoque</option>
                <option value="normal">Estoque Ideal</option>
                <option value="baixa">Baixa de Estoque</option>
                <option value="reabastecer">Ponto de Pedido</option>
            </select>

            <select name="fornecedor">
                <option value="">Filtro por Fornecedor</option>
                <?php
                $fornecedores_sql = "SELECT DISTINCT fornecedor FROM produtos WHERE fornecedor IS NOT NULL";
                $fornecedores_result = $conn->query($fornecedores_sql);
                if ($fornecedores_result && $fornecedores_result->num_rows > 0) {
                    while ($row = $fornecedores_result->fetch_assoc()) {
                        echo "<option value='{$row['fornecedor']}'>{$row['fornecedor']}</option>";
                    }
                }
                ?>
            </select>

            <select name="estoque">
                <option value="principal" <?php if (isset($_POST['estoque']) && $_POST['estoque'] == "principal") echo 'selected'; ?>>Estoque Principal</option>
                <option value="todos" <?php if (isset($_POST['estoque']) && $_POST['estoque'] == "todos") echo 'selected'; ?>>Todos</option>
                <option value="almoxarifado1" <?php if (isset($_POST['estoque']) && $_POST['estoque'] == "almoxarifado1") echo 'selected'; ?>>Almoxarifado 1</option>
                <option value="almoxarifado2" <?php if (isset($_POST['estoque']) && $_POST['estoque'] == "almoxarifado2") echo 'selected'; ?>>Almoxarifado 2</option>
            </select>

            <input type="text" name="busca" placeholder="Buscar por Nome ou ID">
            <button type="submit">Filtrar</button>
        </form>

        <!-- Listagem de Produtos -->
        <table>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Preço</th>
                <th>Lote</th>
                <th>Data de Validade</th>
                <th>Fornecedor</th>
                <th>Estoque Principal</th>
                <th>Almoxarifado 1</th>
                <th>Almoxarifado 2</th>
                <th>Ações</th>
            </tr>
            <?php
            $sql = "SELECT p.id, p.nome, p.descricao, p.preco, p.lote, p.data_validade, p.fornecedor, 
                    COALESCE(ep.quantidade, 0) AS quantidade_estoque_principal, 
                    COALESCE(ea1.quantidade, 0) AS quantidade_almoxarifado1,
                    COALESCE(ea2.quantidade, 0) AS quantidade_almoxarifado2
                    FROM produtos p
                    LEFT JOIN estoque ep ON p.id = ep.produto_id AND ep.localizacao_id = 1
                    LEFT JOIN estoque ea1 ON p.id = ea1.produto_id AND ea1.localizacao_id = 2
                    LEFT JOIN estoque ea2 ON p.id = ea2.produto_id AND ea2.localizacao_id = 3";

            $result = $conn->query($sql);
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['nome']}</td>";
                    echo "<td>{$row['descricao']}</td>";
                    echo "<td>R$ " . number_format($row['preco'], 2, ',', '.') . "</td>";
                    echo "<td>{$row['lote']}</td>";
                    echo "<td>" . date('d/m/Y', strtotime($row['data_validade'])) . "</td>";
                    echo "<td>{$row['fornecedor']}</td>";
                    echo "<td>{$row['quantidade_estoque_principal']}</td>";
                    echo "<td>{$row['quantidade_almoxarifado1']}</td>";
                    echo "<td>{$row['quantidade_almoxarifado2']}</td>";
                    
                    // Ações disponíveis (apenas administradores podem Editar, Inativar e Excluir)
                    echo "<td>";
                    echo "<a href='registrar_uso_interno.php?produto_id=" . $row['id'] . "' class='action-button usage-button'>Uso Interno</a>";
                    if ($usuario_tipo === 'admin') {
                        echo "<a href='editar_produto.php?produto_id=" . $row['id'] . "' class='action-button edit-button'>Editar</a>";
                        echo "<a href='inativar_produto.php?produto_id=" . $row['id'] . "' class='action-button inactivate-button' onclick='return confirm(\"Tem certeza que deseja inativar este produto?\");'>Inativar</a>";
                        echo "<a href='excluir_produto.php?produto_id=" . $row['id'] . "' class='action-button delete-button' onclick='return confirm(\"Tem certeza que deseja excluir este produto?\");'>Excluir</a>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='11'>Nenhum produto encontrado.</td></tr>";
            }
            ?>
        </table>
    </div>
    <footer>
        <p>Ads - Faculdade Fasipe Cuiabá - &copy; 2024</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
