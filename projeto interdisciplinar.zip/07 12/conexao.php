<?php
// Configurações do banco de dados
$host = 'localhost'; // Nome do host ou IP
$usuario = 'root'; // Usuário do MySQL
$senha = ''; // Senha do MySQL
$banco = 'estoque'; // Nome do banco de dados

// Criando a conexão
$conn = new mysqli($host, $usuario, $senha, $banco);

// Verificando a conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
?>
