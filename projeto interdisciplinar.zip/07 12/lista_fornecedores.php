<?php
// Incluir o arquivo de conexão com o banco de dados
include('conexao.php');

// Consultar fornecedores
$sql = "SELECT * FROM fornecedores";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Fornecedores</title>
    <link rel="stylesheet" href="styles.css"> <!-- Adicione seu arquivo CSS aqui -->
</head>
<body>
    <h1>Lista de Fornecedores</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome do Fornecedor</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>" . $row["id"] . "</td><td>" . $row["nome"] . "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Nenhum fornecedor cadastrado</td></tr>";
        }
        ?>
    </table>
    <a href="cadastrar_fornecedor.php">Cadastrar Novo Fornecedor</a>
    <a href="cadastrar_produto.php">Cadastrar Produto</a>
</body>
</html>
