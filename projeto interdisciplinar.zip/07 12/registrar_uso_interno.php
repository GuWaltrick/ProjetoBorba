<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Extrair apenas o nome do usuário
$usuario_nome = $_SESSION['usuario']['nome']; // Assumindo que há uma chave 'nome' na sessão

// Verificar se o usuário tem um estoque permitido ou se é um administrador
$estoque_permitido = $_SESSION['usuario']['tipo'] === 'admin' ? null : $_SESSION['usuario']['estoque_id']; // Admin pode acessar qualquer estoque

if (isset($_GET['produto_id'])) {
    $produto_id = intval($_GET['produto_id']);

    // Consulta para obter as informações do produto
    $sql = "SELECT id, nome, descricao, preco FROM produtos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $produto_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $produto = $result->fetch_assoc();
    } else {
        echo "Produto não encontrado.";
        exit();
    }
} else {
    echo "Produto não especificado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Uso Interno</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            color: #333;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            color: #28a745;
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
            width: 100%;
        }
        button:hover {
            background-color: #218838;
        }
        .alert {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar Uso Interno</h1>
        <form action="saida_uso_interno.php" method="POST">
            <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
            <input type="hidden" name="usuario_nome" value="<?php echo htmlspecialchars($usuario_nome); ?>">

            <label>ID do Produto:</label>
            <p><?php echo htmlspecialchars($produto['id']); ?></p>

            <label>Nome do Produto:</label>
            <p><?php echo htmlspecialchars($produto['nome']); ?></p>

            <label>Descrição:</label>
            <p><?php echo htmlspecialchars($produto['descricao']); ?></p>

            <label>Preço:</label>
            <p>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>

            <label for="estoque">Selecionar Estoque:</label>
            <?php if ($_SESSION['usuario']['tipo'] === 'admin'): ?>
                <select id="estoque" name="estoque" required>
                    <option value="1">Estoque Principal</option>
                    <option value="2">Almoxarifado 1</option>
                    <option value="3">Almoxarifado 2</option>
                </select>
            <?php else: ?>
                <select id="estoque" name="estoque" required>
                    <?php if ($estoque_permitido == 1): ?>
                        <option value="1" selected>Estoque Principal</option>
                    <?php elseif ($estoque_permitido == 2): ?>
                        <option value="2" selected>Almoxarifado 1</option>
                    <?php elseif ($estoque_permitido == 3): ?>
                        <option value="3" selected>Almoxarifado 2</option>
                    <?php endif; ?>
                </select>
                <input type="hidden" name="estoque_permitido" value="<?= $estoque_permitido ?>">
            <?php endif; ?>

            <label for="quantidade">Quantidade:</label>
            <input type="number" id="quantidade" name="quantidade" min="1" required>

            <button type="submit">Registrar Uso Interno</button>
        </form>
        <?php if (isset($_GET['sucesso']) && $_GET['sucesso'] == '1'): ?>
            <div class="alert">Uso interno registrado com sucesso!</div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
