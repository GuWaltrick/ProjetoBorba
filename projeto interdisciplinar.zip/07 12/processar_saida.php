<?php

// Incluir o arquivo de conexão com o banco de dados
include 'conexao.php';

// Exibir erros de PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar buffer de saída
ob_start();

// Verificar se o formulário foi enviado (solicitação de confirmação de saída)
if (isset($_POST['confirmar_saida'])) {
    echo "Processando confirmação de saída...<br>";

    // Capturar os dados da solicitação
    $solicitacao_id = $_POST['solicitacao_id'];
    echo "ID da solicitação recebido: $solicitacao_id<br>";

    if (!$solicitacao_id) {
        echo "ID da solicitação não fornecido.";
        exit;
    }

    // Buscar as informações da solicitação pendente no banco de dados
    $query_solicitacao = "SELECT produto_id, quantidade, almoxarifado_origem, almoxarifado_destino, status FROM solicitacoes WHERE id = ?";
    $stmt = $conn->prepare($query_solicitacao);
    $stmt->bind_param('i', $solicitacao_id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        // Extrair os dados da solicitação
        $solicitacao = $resultado->fetch_assoc();
        $produto_id = $solicitacao['produto_id'];
        $quantidade = $solicitacao['quantidade'];
        $almoxarifado_origem = $solicitacao['almoxarifado_origem'];
        $status_atual = $solicitacao['status'];

        echo "Produto ID: $produto_id, Quantidade: $quantidade, Almoxarifado Origem: $almoxarifado_origem, Status: $status_atual<br>";

        if ($status_atual == 'em_transito') {
            echo "Esta solicitação já está em trânsito.";
            exit;
        }

        // Iniciar uma transação para garantir a consistência dos dados
        $conn->begin_transaction();
        echo "Iniciando transação para confirmação de saída.<br>";

        try {
            // Diminuir a quantidade do produto no almoxarifado remetente (origem)
            $query_atualizar_estoque = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto_id = ? AND localizacao_id = ?";
            $stmt_atualizar = $conn->prepare($query_atualizar_estoque);
            if ($stmt_atualizar === false) {
                throw new Exception("Erro na preparação da consulta de atualização do estoque: " . $conn->error);
            }
            $stmt_atualizar->bind_param('iii', $quantidade, $produto_id,
