<?php
include 'conexao.php';
$query = $_GET['query'] ?? '';
$sql = "SELECT id, nome FROM produtos WHERE nome LIKE '%$query%' OR id LIKE '%$query%' LIMIT 10";
$result = $conn->query($sql);
$suggestions = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $suggestions[] = $row;
    }
}

echo json_encode($suggestions);
?>
