<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
require_once 'conexao.php';

// Verifica permissões do usuário
$permissoes = is_string($_SESSION['usuario']['permissoes']) ? json_decode($_SESSION['usuario']['permissoes'], true) : $_SESSION['usuario']['permissoes'];

// Apenas Admin pode acessar
if ($_SESSION['usuario']['tipo'] !== 'admin') {
    echo "<script>alert('Acesso negado! Somente administradores podem acessar esta página.');</script>";
    header("Location: dashboard.php");
    exit();
}

// Atualizar usuário existente
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $tipo = $_POST['tipo'];
    $estoque = intval($_POST['estoque']);

    // Permissões somente para usuários que não são Admin
    if ($tipo !== 'admin') {
        $permissoes_usuario = isset($_POST['permissoes']) ? json_encode($_POST['permissoes']) : json_encode([]);
    } else {
        $permissoes_usuario = null; // Mantém as permissões do Admin inalteradas
    }

    // Atualizar senha somente se for preenchida
    if (!empty($_POST['senha'])) {
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
        $sql = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, tipo = ?, estoque_id = ?, permissoes = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssiis", $nome, $email, $senha, $tipo, $estoque, $permissoes_usuario, $id);
    } else {
        $sql = "UPDATE usuarios SET nome = ?, email = ?, tipo = ?, estoque_id = ?, permissoes = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssiis", $nome, $email, $tipo, $estoque, $permissoes_usuario, $id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Usuário atualizado com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar usuário.');</script>";
    }
    $stmt->close();
}

// Cadastrar novo usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $tipo = $_POST['tipo'];
    $estoque = intval($_POST['estoque']);
    $permissoes_usuario = isset($_POST['permissoes']) ? json_encode($_POST['permissoes']) : json_encode([]);

    $sql = "INSERT INTO usuarios (nome, email, senha, tipo, estoque_id, permissoes) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $nome, $email, $senha, $tipo, $estoque, $permissoes_usuario);
    if ($stmt->execute()) {
        echo "<script>alert('Usuário cadastrado com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao cadastrar usuário.');</script>";
    }
    $stmt->close();
}

// Excluir usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['excluir'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Usuário excluído com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao excluir usuário.');</script>";
    }
    $stmt->close();
}

// Buscar usuários para exibição
$sql = "SELECT id, nome, email, tipo, estoque_id, permissoes FROM usuarios";
$result = $conn->query($sql);
$usuarios = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .table thead {
            background-color: #28a745;
            color: #fff;
        }
        .action-buttons button {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-5">Gerenciar Usuários</h1>

        <!-- Formulário para cadastrar novo usuário -->
        <div class="card mb-5">
            <div class="card-header bg-success text-white">
                <h3>Cadastrar Novo Usuário</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="nome" class="form-label">Nome:</label>
                            <input type="text" name="nome" id="nome" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">E-mail:</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="senha" class="form-label">Senha:</label>
                            <input type="password" name="senha" id="senha" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="tipo" class="form-label">Tipo:</label>
                            <select name="tipo" id="tipo" class="form-select">
                                <option value="admin">Admin</option>
                                <option value="usuario">Usuário</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="estoque" class="form-label">Estoque do Usuário:</label>
                        <select name="estoque" id="estoque" class="form-select" required>
                            <option value="1">Estoque Principal</option>
                            <option value="2">Almoxarifado 1</option>
                            <option value="3">Almoxarifado 2</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="permissoes" class="form-label">Permissões:</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_usuario]" value="1"> Cadastrar Usuário
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_produto]" value="1"> Cadastrar Produto
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_fornecedor]" value="1"> Cadastrar Fornecedor
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissoes[entrada_produtos_externos]" value="1"> Entrada de Produtos Externos
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="permissoes[relatorios]" value="1"> Relatórios
                        </div>
                    </div>
                    <button type="submit" name="cadastrar" class="btn btn-success w-100">Cadastrar</button>
                </form>
            </div>
        </div>

        <!-- Tabela de usuários cadastrados -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <h3>Usuários Cadastrados</h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Tipo</th>
                            <th>Estoque</th>
                            <th>Permissões</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <form method="POST" action="">
                                    <td><?= $usuario['id'] ?></td>
                                    <td><input type="text" name="nome" value="<?= htmlspecialchars($usuario['nome']) ?>" class="form-control"></td>
                                    <td><input type="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" class="form-control"></td>
                                    <td>
                                        <select name="tipo" class="form-select" <?= $usuario['tipo'] === 'admin' ? 'disabled' : '' ?>>
                                            <option value="admin" <?= $usuario['tipo'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                                            <option value="usuario" <?= $usuario['tipo'] === 'usuario' ? 'selected' : '' ?>>Usuário</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="estoque" class="form-select">
                                            <option value="1" <?= $usuario['estoque_id'] == 1 ? 'selected' : '' ?>>Estoque Principal</option>
                                            <option value="2" <?= $usuario['estoque_id'] == 2 ? 'selected' : '' ?>>Almoxarifado 1</option>
                                            <option value="3" <?= $usuario['estoque_id'] == 3 ? 'selected' : '' ?>>Almoxarifado 2</option>
                                        </select>
                                    </td>
                                    <td>
                                        <?php if ($usuario['tipo'] !== 'admin'): ?>
                                            <?php
                                            $userPermissoes = json_decode($usuario['permissoes'], true) ?: [];
                                            ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_usuario]" value="1" <?= !empty($userPermissoes['cadastrar_usuario']) ? 'checked' : '' ?>> Cadastrar Usuário
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_produto]" value="1" <?= !empty($userPermissoes['cadastrar_produto']) ? 'checked' : '' ?>> Cadastrar Produto
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissoes[cadastrar_fornecedor]" value="1" <?= !empty($userPermissoes['cadastrar_fornecedor']) ? 'checked' : '' ?>> Cadastrar Fornecedor
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissoes[entrada_produtos_externos]" value="1" <?= !empty($userPermissoes['entrada_produtos_externos']) ? 'checked' : '' ?>> Entrada de Produtos Externos
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissoes[relatorios]" value="1" <?= !empty($userPermissoes['relatorios']) ? 'checked' : '' ?>> Relatórios
                                            </div>
                                        <?php else: ?>
                                            <span>-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="action-buttons">
                                        <input type="hidden" name="id" value="<?= $usuario['id'] ?>">
                                        <button type="submit" name="editar" class="btn btn-warning btn-sm">Salvar</button>
                                        <button type="submit" name="excluir" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">Excluir</button>
                                    </td>
                                </form>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
