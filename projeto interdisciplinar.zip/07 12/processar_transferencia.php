<?php
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['solicitacoes'])) {
    $solicitacoes = $_POST['solicitacoes'];

    foreach ($solicitacoes as $solicitacao_id) {
        // Buscar a solicitação específica
        $sql = "SELECT * FROM solicitacoes WHERE id = $solicitacao_id";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $solicitacao = $result->fetch_assoc();
            
            $produto_id = $solicitacao['produto_id'];
            $quantidade = $solicitacao['quantidade'];
            $almoxarifado_origem = $solicitacao['almoxarifado_origem'];
            $almoxarifado_destino = $solicitacao['almoxarifado_destino'];

            // Reduzir a quantidade do almoxarifado de origem
            $sql_estoque_origem = "UPDATE estoque
                                   SET quantidade = quantidade - $quantidade
                                   WHERE produto_id = $produto_id AND localizacao_id = $almoxarifado_origem";
            if (!$conn->query($sql_estoque_origem)) {
                die("Erro ao atualizar o estoque de origem: " . $conn->error);
            }

            // Incrementar a quantidade no almoxarifado de destino
            $sql_estoque_destino = "UPDATE estoque
                                    SET quantidade = quantidade + $quantidade
                                    WHERE produto_id = $produto_id AND localizacao_id = $almoxarifado_destino";
            if (!$conn->query($sql_estoque_destino)) {
                // Caso não exista o registro do produto no almoxarifado de destino, criar um novo registro
                $sql_insert_destino = "INSERT INTO estoque (produto_id, localizacao_id, quantidade)
                                       VALUES ($produto_id, $almoxarifado_destino, $quantidade)";
                if (!$conn->query($sql_insert_destino)) {
                    die("Erro ao incrementar o estoque de destino: " . $conn->error);
                }
            }

            // Excluir a solicitação após o processamento
            $sql_delete = "DELETE FROM solicitacoes WHERE id = $solicitacao_id";
            if (!$conn->query($sql_delete)) {
                die("Erro ao excluir a solicitação: " . $conn->error);
            }

            echo "Transferência processada com sucesso! Produto $produto_id transferido de $almoxarifado_origem para $almoxarifado_destino.<br>";
        } else {
            echo "Solicitação não encontrada. ID: $solicitacao_id<br>";
        }
    }

    echo "<br><a href='ver_solicitacoes.php'>Voltar</a>";
} else {
    echo "Nenhuma solicitação foi selecionada.";
    echo "<br><a href='ver_solicitacoes.php'>Voltar</a>";
}
?>
