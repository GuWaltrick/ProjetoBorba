<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Obter as permissões do usuário logado
$permissoes = isset($_SESSION['usuario']['permissoes']) ? $_SESSION['usuario']['permissoes'] : [];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            text-align: center;
        }
        .container {
            background-color: #ffffff;
            padding: 30px;
            margin: 40px auto;
            width: 90%;
            max-width: 900px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        nav ul li {
            margin: 15px 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #28a745;
            font-size: 18px;
            padding: 12px 25px;
            background-color: #f9f9f9;
            border-radius: 8px;
            transition: background-color 0.3s, color 0.3s;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        nav ul li a.disabled {
            color: #999;
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        nav ul li a:hover:not(.disabled) {
            color: #fff;
            background-color: #28a745;
        }
        .section-title {
            font-size: 26px;
            margin: 25px 0 15px;
            color: #333;
            font-weight: bold;
        }
        footer {
            margin-top: 60px;
            font-size: 14px;
            color: #777;
        }
    </style>
    <script>
        function acessoBloqueado() {
            alert('Acesso negado! Você não tem permissão para acessar esta funcionalidade.');
        }
    </script>
</head>
<body>
    <h1>Bem-vindo ao Estoque <i class="fas fa-warehouse"></i></h1>
    
    <div class="container">
        <div class="section-title">Gerenciamento de Cadastros</div>
        <nav>
            <ul>
                <li>
                    <?php if (!empty($permissoes['cadastrar_produto'])): ?>
                        <a href="cadastrar_produto.php"><i class="fas fa-plus"></i> Cadastrar Produto</a>
                    <?php else: ?>
                        <a href="#" class="disabled" onclick="acessoBloqueado()"><i class="fas fa-plus"></i> Cadastrar Produto</a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($permissoes['cadastrar_fornecedor'])): ?>
                        <a href="cadastrar_fornecedor.php"><i class="fas fa-truck"></i> Cadastrar Fornecedor</a>
                    <?php else: ?>
                        <a href="#" class="disabled" onclick="acessoBloqueado()"><i class="fas fa-truck"></i> Cadastrar Fornecedor</a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if (!empty($permissoes['cadastrar_usuario'])): ?>
                        <a href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> Cadastrar Usuário</a>
                    <?php else: ?>
                        <a href="#" class="disabled" onclick="acessoBloqueado()"><i class="fas fa-user-plus"></i> Cadastrar Usuário</a>
                    <?php endif; ?>
                </li>
                <li><a href="ver_produtos.php"><i class="fas fa-list"></i> Ver Produtos</a></li>
            </ul>
        </nav>

        <div class="section-title">Operações Logísticas</div>
        <nav>
            <ul>
                <li>
                    <?php if (!empty($permissoes['entrada_produtos'])): ?>
                        <a href="entrada_produto.php"><i class="fas fa-arrow-down"></i> Entrada de Produtos</a>
                    <?php else: ?>
                        <a href="#" class="disabled" onclick="acessoBloqueado()"><i class="fas fa-arrow-down"></i> Entrada de Produtos</a>
                    <?php endif; ?>
                </li>
                <li><a href="movimentacoes.php"><i class="fas fa-exchange-alt"></i> Movimentações</a></li>
                <li><a href="solicitar_transferencia.php"><i class="fas fa-arrow-right"></i> Solicitar Transferência</a></li>
                <li><a href="ver_solicitacoes.php"><i class="fas fa-tasks"></i> Solicitações Pendentes</a></li>
            </ul>
        </nav>

        <div class="section-title">Relatórios</div>
        <nav>
            <ul>
                <li>
                    <?php if (!empty($permissoes['relatorios'])): ?>
                        <a href="relatorios.php"><i class="fas fa-file-alt"></i> Relatórios</a>
                    <?php else: ?>
                        <a href="#" class="disabled" onclick="acessoBloqueado()"><i class="fas fa-file-alt"></i> Relatórios</a>
                    <?php endif; ?>
                </li>
            </ul>
        </nav>
    </div>
    
    <footer>
        <p>Ads - Faculdade Fasipe Cuiabá - &copy; 2024</p>
    </footer>
</body>
</html>
