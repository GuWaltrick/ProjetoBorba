<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['tipo'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "estoque");
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Atualizar permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioId = $_POST['usuario_id'];
    $permissoes = isset($_POST['permissoes']) ? $_POST['permissoes'] : [];

    // Atualiza permissões na tabela de usuários
    $jsonPermissoes = json_encode($permissoes);
    $stmt = $conn->prepare("UPDATE usuarios SET permissoes = ? WHERE id = ?");
    $stmt->bind_param("si", $jsonPermissoes, $usuarioId);
    $stmt->execute();
}

// Obter todos os usuários
$result = $conn->query("SELECT id, nome, email, permissoes FROM usuarios");
$usuarios = $result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários</title>
</head>
<body>
    <h1>Gerenciar Usuários</h1>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Permissões</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <?php 
                // Decodifica as permissões armazenadas
                $permissoes = json_decode($usuario['permissoes'], true) ?: [];
                ?>
                <tr>
                    <td><?php echo $usuario['id']; ?></td>
                    <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                    <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="usuario_id" value="<?php echo $usuario['id']; ?>">
                            <label>
                                <input type="checkbox" name="permissoes[cadastrar_usuario]" 
                                    <?php echo isset($permissoes['cadastrar_usuario']) && $permissoes['cadastrar_usuario'] ? 'checked' : ''; ?>>
                                Cadastrar Usuário
                            </label>
                            <label>
                                <input type="checkbox" name="permissoes[cadastrar_produto]" 
                                    <?php echo isset($permissoes['cadastrar_produto']) && $permissoes['cadastrar_produto'] ? 'checked' : ''; ?>>
                                Cadastrar Produto
                            </label>
                            <button type="submit">Salvar</button>
                        </form>
                    </td>
                    <td>
                        <a href="remover_usuario.php?id=<?php echo $usuario['id']; ?>" 
                           onclick="return confirm('Tem certeza que deseja remover este usuário?');">Remover</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
