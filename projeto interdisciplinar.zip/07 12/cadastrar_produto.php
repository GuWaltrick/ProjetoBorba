<?php
include 'conexao.php'; // Incluindo a conexão com o banco de dados
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Código para processar o envio do formulário (inserir produto no banco)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $fornecedor = $_POST['fornecedor'];
    $estoque_minimo = $_POST['estoque_minimo'];
    $estoque_maximo = $_POST['estoque_maximo'];
    $ponto_pedido = $_POST['ponto_pedido'];

    // Inserir o produto na tabela de produtos
    $sql = "INSERT INTO produtos (nome, descricao, preco, fornecedor, estoque_minimo, estoque_maximo, ponto_de_pedido)
            VALUES ('$nome', '$descricao', '$preco', '$fornecedor', '$estoque_minimo', '$estoque_maximo', '$ponto_pedido')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Produto cadastrado com sucesso!</div>";
    } else {
        echo "<div class='error'>Erro ao cadastrar o produto: " . $conn->error . "</div>";
    }
}

// Carregar fornecedores únicos da tabela produtos
$sql_fornecedores = "SELECT DISTINCT fornecedor FROM produtos WHERE fornecedor IS NOT NULL AND fornecedor != ''";
$result_fornecedores = $conn->query($sql_fornecedores);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Produto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Cadastro de Produto</h1>
        <form action="" method="POST">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <textarea id="descricao" name="descricao" required></textarea>
            </div>

            <div class="form-group">
                <label for="preco">Preço:</label>
                <input type="number" id="preco" name="preco" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="fornecedor">Fornecedor:</label>
                <select id="fornecedor" name="fornecedor" required>
                    <option value="">Selecione um fornecedor</option>
                    <?php
                    // Exibir opções de fornecedores ou mostrar mensagem de erro
                    if ($result_fornecedores && $result_fornecedores->num_rows > 0) {
                        while ($row = $result_fornecedores->fetch_assoc()) {
                            echo "<option value='" . $row['fornecedor'] . "'>" . $row['fornecedor'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>Nenhum fornecedor disponível</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="estoque_minimo">Estoque Mínimo:</label>
                <input type="number" id="estoque_minimo" name="estoque_minimo" required>
            </div>

            <div class="form-group">
                <label for="estoque_maximo">Estoque Máximo:</label>
                <input type="number" id="estoque_maximo" name="estoque_maximo" required>
            </div>

            <div class="form-group">
                <label for="ponto_pedido">Ponto de Pedido:</label>
                <input type="number" id="ponto_pedido" name="ponto_pedido" required>
            </div>

            <div class="form-buttons">
                <button type="submit">Cadastrar Produto</button>
                <button type="reset">Limpar Formulário</button>
            </div>
        </form>
    </div>
</body>
</html>
