<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['confirmar_saida']) && isset($_POST['solicitacoes_saida'])) {
    $solicitacoes_saida = $_POST['solicitacoes_saida'];

    foreach ($solicitacoes_saida as $solicitacao_id) {
        // Atualizar o status da solicitação para 'em_transito'
        $query_update_status = "UPDATE solicitacoes SET status = 'em_transito' WHERE id = ?";
        $stmt_status = $conn->prepare($query_update_status);
        $stmt_status->bind_param('i', $solicitacao_id);
        $stmt_status->execute();
        $stmt_status->close();

        // Buscar a solicitação para obter os dados necessários
        $query_solicitacao = "SELECT produto_id, quantidade, almoxarifado_origem, almoxarifado_destino FROM solicitacoes WHERE id = ?";
        $stmt_solicitacao = $conn->prepare($query_solicitacao);
        $stmt_solicitacao->bind_param('i', $solicitacao_id);
        $stmt_solicitacao->execute();
        $resultado_solicitacao = $stmt_solicitacao->get_result();

        if ($resultado_solicitacao->num_rows > 0) {
            $solicitacao = $resultado_solicitacao->fetch_assoc();
            $produto_id = $solicitacao['produto_id'];
            $quantidade = $solicitacao['quantidade'];
            $almoxarifado_origem = $solicitacao['almoxarifado_origem'];
            $almoxarifado_destino = $solicitacao['almoxarifado_destino'];

            // Atualizar o estoque do almoxarifado de origem
            $query_update_estoque = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto_id = ? AND localizacao_id = ?";
            $stmt_estoque = $conn->prepare($query_update_estoque);
            $stmt_estoque->bind_param('iii', $quantidade, $produto_id, $almoxarifado_origem);
            $stmt_estoque->execute();
            $stmt_estoque->close();

            // Inserir uma movimentação de saída
            $query_movimentacao = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, estoque_origem_id, estoque_destino_id, usuario, data_movimentacao)
                                   VALUES (?, ?, 'saida', ?, ?, ?, NOW())";
            $stmt_movimentacao = $conn->prepare($query_movimentacao);
            $stmt_movimentacao->bind_param('iiiis', $produto_id, $quantidade, $almoxarifado_origem, $almoxarifado_destino, $_SESSION['usuario']);
            $stmt_movimentacao->execute();
            $stmt_movimentacao->close();
        }

        $stmt_solicitacao->close();
    }

    echo "Solicitação de saída confirmada e estoque atualizado com sucesso.";
    header("Location: ver_solicitacoes.php");
    exit();
} else {
    echo "Nenhuma solicitação foi selecionada.";
}
?>
