<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Fornecedor</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Cadastrar Fornecedor</h1>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['novo_fornecedor'])) {
        $novo_fornecedor = $_POST['novo_fornecedor'];

        // Verifica se o fornecedor já existe
        $fornecedor_existe_sql = "SELECT fornecedor FROM produtos WHERE fornecedor = '$novo_fornecedor'";
        $fornecedor_existe_result = $conn->query($fornecedor_existe_sql);

        if ($fornecedor_existe_result->num_rows == 0) {
            // Se o fornecedor não existir, insira-o como um novo fornecedor (usando a tabela de produtos)
            $inserir_fornecedor_sql = "INSERT INTO produtos (fornecedor) VALUES ('$novo_fornecedor')";
            if ($conn->query($inserir_fornecedor_sql) === TRUE) {
                echo "<div class='alert'>Novo fornecedor cadastrado com sucesso!</div>";
            } else {
                echo "Erro ao cadastrar fornecedor: " . $conn->error;
            }
        } else {
            echo "<div class='alert'>O fornecedor já está cadastrado!</div>";
        }
    }
    ?>

    <!-- Formulário para cadastrar novo fornecedor -->
    <form method="post">
        Novo Fornecedor: <input type="text" name="novo_fornecedor" required><br><br>
        <button type="submit">Registrar Fornecedor</button>
    </form>

    <p><a href="cadastrar_produto.php">Voltar para Cadastro de Produtos</a></p>

</body>
</html>
