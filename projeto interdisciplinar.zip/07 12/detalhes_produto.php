<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Verifica o ID do produto passado na URL
$produto_id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if ($produto_id === null) {
    echo "Produto não encontrado.";
    exit();
}

// Função para alternar o status ativo/inativo do produto
if (isset($_GET['toggle_ativo'])) {
    $sql = "UPDATE produtos SET ativo = IF(ativo=1, 0, 1) WHERE id = $produto_id";
    if ($conn->query($sql) === TRUE) {
        header("Location: detalhes_produto.php?id=$produto_id"); // Redireciona para a mesma página após alternar o status
        exit();
    } else {
        echo "Erro ao atualizar o status do produto: " . $conn->error;
        exit();
    }
}

// Consulta para obter os detalhes do produto
$sql_produto = "SELECT * FROM produtos WHERE id = $produto_id";
$result_produto = $conn->query($sql_produto);

if ($result_produto && $result_produto->num_rows > 0) {
    $produto = $result_produto->fetch_assoc();
    $status = $produto['ativo'] == 1 ? "Ativo" : "Inativo";
} else {
    echo "Produto não encontrado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Produto</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            padding: 20px;
        }
        .btn-toggle {
            display: inline-block;
            padding: 10px 15px;
            color: white;
            text-decoration: none;
            margin-top: 20px;
            border-radius: 5px;
            background-color: <?php echo $produto['ativo'] == 1 ? '#dc3545' : '#28a745'; ?>;
        }
        .btn-toggle:hover {
            background-color: <?php echo $produto['ativo'] == 1 ? '#c82333' : '#218838'; ?>;
        }
    </style>
</head>
<body>
    <h1>Detalhes do Produto: <?php echo htmlspecialchars($produto['nome']); ?></h1>
    <p>Descrição: <?php echo htmlspecialchars($produto['descricao']); ?></p>
    <p>Preço: R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
    <p>Lote: <?php echo htmlspecialchars($produto['lote']); ?></p>
    <p>Data de Validade: <?php echo date('d/m/Y', strtotime($produto['data_validade'])); ?></p>
    <p>Fornecedor: <?php echo htmlspecialchars($produto['fornecedor']); ?></p>
    <p>Status: <?php echo $status; ?></p>

    <!-- Botão para alternar entre ativo/inativo -->
    <a href="detalhes_produto.php?id=<?php echo $produto_id; ?>&toggle_ativo=1" class="btn-toggle">
        <?php echo $produto['ativo'] == 1 ? 'Inativar Produto' : 'Ativar Produto'; ?>
    </a>

    <h2>Movimentações de Estoque</h2>
    <table>
        <tr>
            <th>Tipo</th>
            <th>Quantidade</th>
            <th>Data da Movimentação</th>
        </tr>
        <?php
        // Exemplo de movimentações, ajustar a consulta conforme o banco de dados
        $sql_movimentacoes = "SELECT tipo, quantidade, data_movimentacao FROM movimentacoes WHERE produto_id = $produto_id ORDER BY data_movimentacao DESC";
        $result_movimentacoes = $conn->query($sql_movimentacoes);

        if ($result_movimentacoes && $result_movimentacoes->num_rows > 0) {
            while($mov = $result_movimentacoes->fetch_assoc()) {
                echo "<tr>
                        <td>{$mov['tipo']}</td>
                        <td>{$mov['quantidade']}</td>
                        <td>" . date('d/m/Y H:i:s', strtotime($mov['data_movimentacao'])) . "</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Nenhuma movimentação encontrada.</td></tr>";
        }
        ?>
    </table>

    <footer>
        <p>Ads - Faculdade Fasipe Cuiabá - © 2024</p>
    </footer>
</body>
</html>
