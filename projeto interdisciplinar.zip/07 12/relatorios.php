<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "estoque");
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Função para remover acentos
function removerAcentos($string) {
    return preg_replace(
        array(
            "/(á|à|ã|â|ä)/", "/(Á|À|Ã|Â|Ä)/",
            "/(é|è|ê|ë)/",    "/(É|È|Ê|Ë)/",
            "/(í|ì|î|ï)/",    "/(Í|Ì|Î|Ï)/",
            "/(ó|ò|õ|ô|ö)/",  "/(Ó|Ò|Õ|Ô|Ö)/",
            "/(ú|ù|û|ü)/",    "/(Ú|Ù|Û|Ü)/",
            "/(ñ)/",          "/(Ñ)/",
            "/(ç)/",          "/(Ç)/"
        ),
        explode(" ", "a A e E i I o O u U n N c C"),
        $string
    );
}

// Função para gerar PDF
function gerarPDF($titulo, $relatorios) {
    require('fpdf/fpdf.php');

    // Remover acentos do título
    $titulo = removerAcentos("Relatorio de Produtos " . ucfirst(str_replace('_', ' ', $titulo)));

    // Criação do objeto PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Título
    $pdf->Cell(0, 10, $titulo, 0, 1, 'C');
    $pdf->Ln(10);

    // Cabeçalho da tabela
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(80, 10, 'Nome do Produto', 1);
    $pdf->Cell(40, 10, 'Quantidade', 1);
    $pdf->Cell(60, 10, 'Data Validade', 1);
    $pdf->Ln();

    // Dados da tabela
    $pdf->SetFont('Arial', '', 12);
    foreach ($relatorios as $relatorio) {
        $pdf->Cell(80, 10, $relatorio['nome'], 1);
        $pdf->Cell(40, 10, $relatorio['quantidade'], 1);
        $pdf->Cell(60, 10, $relatorio['data_validade'], 1);
        $pdf->Ln();
    }

    // Saída do PDF
    $pdf->Output('D', 'relatorio.pdf');
    exit; // Certifique-se de que nada mais é enviado após isso
}

// Verifica se um tipo de relatório foi solicitado
$tipoRelatorio = isset($_POST['tipo_relatorio']) ? $_POST['tipo_relatorio'] : '';

$relatorios = [];
if ($tipoRelatorio === 'baixa_estoque') {
    $query = "SELECT nome, quantidade, data_validade FROM produtos WHERE quantidade < ponto_de_pedido";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $relatorios[] = $row;
    }
} elseif ($tipoRelatorio === 'alta_estoque') {
    $query = "SELECT nome, quantidade, data_validade FROM produtos WHERE quantidade >= ponto_de_pedido";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $relatorios[] = $row;
    }
} elseif ($tipoRelatorio === 'vencidos') {
    $query = "SELECT nome, quantidade, data_validade FROM produtos WHERE data_validade < NOW()";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $relatorios[] = $row;
    }
} elseif ($tipoRelatorio === 'ponto_pedido') {
    $query = "SELECT nome, quantidade, data_validade FROM produtos WHERE quantidade <= ponto_de_pedido";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $relatorios[] = $row;
    }
}
$conn->close();

// Gerar PDF se o botão foi clicado
if (isset($_POST['gerar_pdf'])) {
    gerarPDF($tipoRelatorio, $relatorios);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="seu-estilo.css"> <!-- Substitua pelo caminho correto do seu CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        h1 {
            color: #28a745;
        }
        form {
            margin: 20px 0;
        }
        select, button {
            padding: 10px;
            font-size: 16px;
            margin: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #28a745;
            color: white;
        }
        .print-button {
            background-color: #007bff;
            margin-top: 20px;
        }
        .print-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Relatórios de Estoque</h1>
        <form method="POST" action="">
            <select name="tipo_relatorio" required>
                <option value="" disabled selected>Escolha um tipo de relatório</option>
                <option value="baixa_estoque">Produtos com Baixa de Estoque</option>
                <option value="alta_estoque">Produtos com Alta de Estoque</option>
                <option value="vencidos">Produtos Vencidos</option>
                <option value="ponto_pedido">Produtos no Ponto de Pedido</option>
            </select>
            <button type="submit">Gerar Relatório</button>
        </form>

        <?php if (!empty($relatorios)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Nome do Produto</th>
                        <th>Quantidade</th>
                        <th>Data Validade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($relatorios as $relatorio): ?>
                        <tr>
                            <td><?php echo $relatorio['nome']; ?></td>
                            <td><?php echo $relatorio['quantidade']; ?></td>
                            <td><?php echo $relatorio['data_validade']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <form method="POST" action="">
                <input type="hidden" name="tipo_relatorio" value="<?php echo $tipoRelatorio; ?>">
                <button type="submit" class="print-button" name="gerar_pdf">Gerar PDF</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
