<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include 'conexao.php';

// Exibir erros para depuração
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Processamento da transferência de produtos
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['transferir'])) {
    $produtos = $_POST['produtos'];
    $estoque_origem_id = $_POST['estoque_origem_id'];
    $estoque_destino_id = $_POST['estoque_destino_id'];
    $observacao = isset($_POST['observacao']) ? $_POST['observacao'] : '';

    if ($estoque_origem_id == $estoque_destino_id) {
        echo "<div class='error'>O estoque de origem e destino não podem ser iguais.</div>";
    } else {
        $nf_sql = "SELECT MAX(numero_nf) AS max_nf FROM notas_fiscais";
        $nf_result = $conn->query($nf_sql);
        $nf_row = $nf_result->fetch_assoc();
        $novo_nf = $nf_row['max_nf'] + 1;

        $insere_nf_sql = "INSERT INTO notas_fiscais (numero_nf) VALUES ($novo_nf)";
        if ($conn->query($insere_nf_sql) === false) {
            echo "<div class='error'>Erro ao inserir número de NF: " . $conn->error . "</div>";
            exit();
        }

        foreach ($produtos as $produto) {
            $produto_id = $produto['id'];
            $quantidade = $produto['quantidade'];

            $verifica_quantidade_sql = "SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = $estoque_origem_id";
            $verifica_result = $conn->query($verifica_quantidade_sql);

            if ($verifica_result === false || $verifica_result->num_rows == 0) {
                echo "<div class='error'>Produto não encontrado no estoque de origem.</div>";
                continue;
            }

            $row = $verifica_result->fetch_assoc();
            if ($row['quantidade'] >= $quantidade) {
                $atualiza_origem_sql = "UPDATE estoque SET quantidade = quantidade - $quantidade WHERE produto_id = $produto_id AND localizacao_id = $estoque_origem_id";
                $conn->query($atualiza_origem_sql);

                $verifica_destino_sql = "SELECT quantidade FROM estoque WHERE produto_id = $produto_id AND localizacao_id = $estoque_destino_id";
                $verifica_destino_result = $conn->query($verifica_destino_sql);

                if ($verifica_destino_result && $verifica_destino_result->num_rows > 0) {
                    $atualiza_destino_sql = "UPDATE estoque SET quantidade = quantidade + $quantidade WHERE produto_id = $produto_id AND localizacao_id = $estoque_destino_id";
                    $conn->query($atualiza_destino_sql);
                } else {
                    $insere_destino_sql = "INSERT INTO estoque (produto_id, localizacao_id, quantidade) VALUES ($produto_id, $estoque_destino_id, $quantidade)";
                    $conn->query($insere_destino_sql);
                }

                $insere_movimentacao_saida = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf)
                                              VALUES ($produto_id, $quantidade, 'NF Saída', 'Transferência para Estoque Destino - $observacao', '{$_SESSION['usuario']}', NOW(), $novo_nf)";
                $conn->query($insere_movimentacao_saida);

                $insere_movimentacao_entrada = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, observacao, usuario, data_movimentacao, numero_nf)
                                                VALUES ($produto_id, $quantidade, 'NF Entrada', 'Recebido de Estoque Origem - $observacao', '{$_SESSION['usuario']}', NOW(), $novo_nf)";
                $conn->query($insere_movimentacao_entrada);

                echo "<div class='success'>Transferência realizada com sucesso! Nota Fiscal: NF " . str_pad($novo_nf, 5, '0', STR_PAD_LEFT) . "</div>";
            } else {
                echo "<div class='error'>Quantidade insuficiente no estoque de origem.</div>";
            }
        }
    }
}

// Buscar estoques
$estoques_sql = "SELECT id, descricao FROM localizacao";
$estoques_result = $conn->query($estoques_sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transferência de Produtos</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .container { max-width: 800px; margin: 0 auto; padding: 20px; background-color: #fff; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: bold; }
        .form-group input, .form-group select { width: 100%; padding: 8px; margin-top: 5px; }
        .product-row { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
        .product-row input, .product-row button { padding: 5px; }
        #suggestions { background: #fff; border: 1px solid #ccc; max-height: 100px; overflow-y: auto; }
        .suggestion-item { padding: 8px; cursor: pointer; }
        .suggestion-item:hover { background: #eee; }
    </style>
    <script>
        async function searchProduct(input, index) {
            const query = input.value;
            if (query.length < 1) {
                document.getElementById(`suggestions-${index}`).innerHTML = '';
                return;
            }
            const response = await fetch(`search_product.php?query=${query}`);
            const suggestions = await response.json();

            let suggestionsList = '';
            suggestions.forEach(suggestion => {
                suggestionsList += `<div class="suggestion-item" onclick="selectProduct('${suggestion.id}', '${suggestion.nome}', ${index})">${suggestion.nome}</div>`;
            });
            document.getElementById(`suggestions-${index}`).innerHTML = suggestionsList;
        }

        function selectProduct(id, nome, index) {
            document.getElementById(`product-id-${index}`).value = id;
            document.getElementById(`product-name-${index}`).value = nome;
            document.getElementById(`suggestions-${index}`).innerHTML = '';
        }

        function addProduct() {
            const productSection = document.getElementById('product-section');
            const newProductRow = document.createElement('div');
            const index = document.querySelectorAll('.product-row').length;
            newProductRow.classList.add('product-row');
            newProductRow.innerHTML = `
                <input type="hidden" name="produtos[${index}][id]" id="product-id-${index}" required>
                <input type="text" name="produtos[${index}][busca]" id="product-name-${index}" oninput="searchProduct(this, ${index})" placeholder="Digite o nome ou ID do produto" required>
                <input type="number" name="produtos[${index}][quantidade]" placeholder="Quantidade" required min="1">
                <div id="suggestions-${index}" class="suggestions"></div>
                <button type="button" onclick="removeProduct(this)">-</button>
            `;
            productSection.appendChild(newProductRow);
        }

        function removeProduct(button) {
            button.parentElement.remove();
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Transferência de Produtos</h1>
        <form method="POST" action="">
            <!-- Informações gerais -->
            <div class="form-group">
                <label for="estoque_origem_id">Estoque de Origem:</label>
                <select id="estoque_origem_id" name="estoque_origem_id" required>
                    <option value="">Selecione o estoque de origem</option>
                    <?php foreach ($estoques_result as $estoque): ?>
                        <option value="<?= $estoque['id'] ?>"><?= $estoque['descricao'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="estoque_destino_id">Estoque de Destino:</label>
                <select id="estoque_destino_id" name="estoque_destino_id" required>
                    <option value="">Selecione o estoque de destino</option>
                    <?php foreach ($estoques_result as $estoque): ?>
                        <option value="<?= $estoque['id'] ?>"><?= $estoque['descricao'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="observacao">Observação:</label>
                <input type="text" id="observacao" name="observacao" placeholder="Digite uma observação opcional">
            </div>

            <!-- Seção de produtos -->
            <div id="product-section">
                <div class="product-row">
                    <input type="hidden" name="produtos[0][id]" id="product-id-0" required>
                    <input type="text" name="produtos[0][busca]" id="product-name-0" oninput="searchProduct(this, 0)" placeholder="Digite o nome ou ID do produto" required>
                    <input type="number" name="produtos[0][quantidade]" placeholder="Quantidade" required min="1">
                    <div id="suggestions-0" class="suggestions"></div>
                    <button type="button" onclick="addProduct()">+</button>
                </div>
            </div>

            <div class="form-buttons">
                <button type="submit" name="transferir">Transferir</button>
            </div>
        </form>
    </div>
</body>
</html>
