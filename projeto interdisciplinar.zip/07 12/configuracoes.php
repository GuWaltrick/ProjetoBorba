<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "estoque");
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Função para mudar a senha
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['alterar_senha'])) {
    $senha_atual = $_POST['senha_atual'];
    $nova_senha = $_POST['nova_senha'];
    
    // Obter ID do usuário logado
    $usuario_id = $_SESSION['usuario']['id'];
    
    // Verifique se a senha atual está correta
    $query = "SELECT senha FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($senha_atual, $row['senha'])) {
            // Atualize a nova senha
            $nova_senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
            $update_query = "UPDATE usuarios SET senha = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("si", $nova_senha_hash, $usuario_id);
            
            if ($update_stmt->execute()) {
                $mensagem = "Senha alterada com sucesso.";
            } else {
                $mensagem = "Erro ao alterar a senha.";
            }
        } else {
            $mensagem = "Senha atual incorreta.";
        }
    } else {
        $mensagem = "Usuário não encontrado.";
    }
    
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="seu-estilo.css"> <!-- Substitua pelo caminho correto do seu CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            text-align: center;
        }
        .form-container {
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .form-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container button {
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            width: 100%;
        }
        .form-container button:hover {
            background-color: #218838;
        }
        .message {
            margin-top: 20px;
            color: #ff0000;
        }
    </style>
</head>
<body>
    <h1>Configurações</h1>
    <div class="form-container">
        <form method="POST">
            <input type="password" name="senha_atual" placeholder="Senha Atual" required>
            <input type="password" name="nova_senha" placeholder="Nova Senha" required>
            <button type="submit" name="alterar_senha">Alterar Senha</button>
        </form>
        <?php if (isset($mensagem)): ?>
            <div class="message"><?php echo $mensagem; ?></div>
        <?php endif; ?>
    </div>
    <footer>
        <p><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></p>
    </footer>
</body>
</html>
