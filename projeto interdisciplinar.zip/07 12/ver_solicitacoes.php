<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$usuario = $_SESSION['usuario'];
$estoque_id_usuario = $usuario['estoque_id']; // Estoque ao qual o usuário tem acesso
$usuario_tipo = $usuario['tipo'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Solicitações - Ver Solicitações</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #eaf0f6;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 90%;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #007bff;
            font-size: 1.8em;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 1em;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
        }
        button:hover {
            background-color: #218838;
        }
        input[type="checkbox"] {
            transform: scale(1.2);
        }
        .toast {
            visibility: hidden;
            min-width: 250px;
            margin-left: -125px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 2px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 30px;
            font-size: 17px;
        }
        .toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 14.5s;
            animation: fadein 0.5s, fadeout 0.5s 14.5s;
        }
        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }
        @keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }
        @-webkit-keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
        @keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            table, th, td {
                font-size: 0.9em;
            }
            button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Solicitações Pendentes (Saída)</h1>
        <form method="POST" action="confirma_saida.php">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Destino</th>
                        <th>Status</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta SQL para buscar as solicitações pendentes de envio
                    $sql_pendentes = "SELECT s.id, p.nome AS produto, s.quantidade, l.descricao AS destino, s.status, s.almoxarifado_origem
                                      FROM solicitacoes s
                                      JOIN produtos p ON s.produto_id = p.id
                                      JOIN localizacao l ON s.almoxarifado_destino = l.id
                                      WHERE s.status = 'aguardando_envio'";

                    $result_pendentes = $conn->query($sql_pendentes);

                    if ($result_pendentes && $result_pendentes->num_rows > 0) {
                        // Exibir cada linha da consulta
                        while ($row = $result_pendentes->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']) ?></td>
                                <td><?= htmlspecialchars($row['produto']) ?></td>
                                <td><?= htmlspecialchars($row['quantidade']) ?></td>
                                <td><?= htmlspecialchars($row['destino']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                                <td>
                                    <?php if ($usuario_tipo === 'admin' || $row['almoxarifado_origem'] == $estoque_id_usuario): ?>
                                        <input type="checkbox" name="solicitacoes_saida[]" value="<?= htmlspecialchars($row['id']) ?>">
                                    <?php else: ?>
                                        <span>Sem permissão</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile;
                    } else {
                        echo "<tr><td colspan='6'>Nenhuma solicitação pendente encontrada.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <button type="submit" name="confirmar_saida">Confirmar Saída</button>
        </form>

        <h1>Produtos Prontos para Entrada (Entrada)</h1>
        <form method="POST" action="confirma_entrada.php">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Origem</th>
                        <th>Status</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta SQL para buscar produtos em trânsito
                    $sql_transito = "SELECT s.id, p.nome AS produto, s.quantidade, l.descricao AS origem, s.status, s.almoxarifado_destino
                                     FROM solicitacoes s
                                     JOIN produtos p ON s.produto_id = p.id
                                     JOIN localizacao l ON s.almoxarifado_origem = l.id
                                     WHERE s.status = 'em_transito'";

                    $result_transito = $conn->query($sql_transito);

                    if ($result_transito && $result_transito->num_rows > 0) {
                        while ($row = $result_transito->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']) ?></td>
                                <td><?= htmlspecialchars($row['produto']) ?></td>
                                <td><?= htmlspecialchars($row['quantidade']) ?></td>
                                <td><?= htmlspecialchars($row['origem']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                                <td>
                                    <?php if ($usuario_tipo === 'admin' || $row['almoxarifado_destino'] == $estoque_id_usuario): ?>
                                        <input type="checkbox" name="solicitacoes_entrada[]" value="<?= htmlspecialchars($row['id']) ?>">
                                    <?php else: ?>
                                        <span>Sem permissão</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile;
                    } else {
                        echo "<tr><td colspan='6'>Nenhum produto encontrado para entrada.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <button type="submit" name="confirmar_entrada">Confirmar Entrada</button>
        </form>
    </div>

    <div id="toast" class="toast">Ação realizada com sucesso!</div>
    <script>
        function showToast() {
            var toast = document.getElementById("toast");
            toast.className = "toast show";
            setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 15000);
        }

        <?php if (isset($_GET['acao_realizada'])): ?>
            showToast();
        <?php endif; ?>
    </script>
</body>
</html>
