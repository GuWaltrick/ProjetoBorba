<?php
include 'conexao.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Inserir lote no banco de dados
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = $_POST['produto_id'];
    $numero_lote = $_POST['numero_lote'];
    $data_fabricacao = $_POST['data_fabricacao'];
    $data_validade = $_POST['data_validade'];
    $quantidade = $_POST['quantidade'];

    $sql = "INSERT INTO lotes (produto_id, numero_lote, data_fabricacao, data_validade, quantidade) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssi", $produto_id, $numero_lote, $data_fabricacao, $data_validade, $quantidade);
    
    if ($stmt->execute()) {
        echo "Lote registrado com sucesso!";
    } else {
        echo "Erro ao registrar o lote.";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Lote</title>
</head>
<body>
    <h1>Adicionar Lote</h1>
    <form method="POST">
        <label>Produto:</label>
        <select name="produto_id">
            <?php
            $sql_produtos = "SELECT id, nome FROM produtos";
            $result_produtos = $conn->query($sql_produtos);
            while ($produto = $result_produtos->fetch_assoc()) {
                echo "<option value='{$produto['id']}'>{$produto['nome']}</option>";
            }
            ?>
        </select><br><br>
        <label>Número do Lote:</label>
        <input type="text" name="numero_lote" required><br><br>
        <label>Data de Fabricação:</label>
        <input type="date" name="data_fabricacao" required><br><br>
        <label>Data de Validade:</label>
        <input type="date" name="data_validade" required><br><br>
        <label>Quantidade:</label>
        <input type="number" name="quantidade" required><br><br>
        <button type="submit">Adicionar Lote</button>
    </form>
</body>
</html>
