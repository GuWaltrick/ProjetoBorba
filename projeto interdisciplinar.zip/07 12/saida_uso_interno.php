<?php
include 'conexao.php'; // Incluindo o arquivo de conexão
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capturando os dados enviados pelo formulário
    $produto_id = intval($_POST['produto_id']);
    $estoque_id = intval($_POST['estoque']);
    $quantidade = intval($_POST['quantidade']);

    // Consulta para verificar se há quantidade suficiente no estoque
    $sql_verificar_estoque = "SELECT quantidade FROM estoque WHERE produto_id = ? AND localizacao_id = ?";
    $stmt_verificar = $conn->prepare($sql_verificar_estoque);
    $stmt_verificar->bind_param("ii", $produto_id, $estoque_id);
    $stmt_verificar->execute();
    $result_verificar = $stmt_verificar->get_result();

    if ($result_verificar->num_rows > 0) {
        $estoque = $result_verificar->fetch_assoc();
        if ($estoque['quantidade'] >= $quantidade) {
            // Atualizar o estoque, removendo a quantidade usada
            $sql_atualizar_estoque = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto_id = ? AND localizacao_id = ?";
            $stmt_atualizar = $conn->prepare($sql_atualizar_estoque);
            $stmt_atualizar->bind_param("iii", $quantidade, $produto_id, $estoque_id);
            if ($stmt_atualizar->execute()) {
                // Inserir registro de movimentação de uso interno
                $sql_movimentacao = "INSERT INTO movimentacoes (produto_id, quantidade, tipo, estoque_origem_id, usuario, data_movimentacao, motivo) 
                                     VALUES (?, ?, 'saida', ?, ?, NOW(), 'Uso Interno')";
                $stmt_movimentacao = $conn->prepare($sql_movimentacao);

                // Extrair o nome ou identificador do usuário corretamente
                $usuario = $_SESSION['usuario']['nome'] ?? 'Desconhecido'; // Ajuste conforme o campo que você tem na sessão

                $stmt_movimentacao->bind_param("iiis", $produto_id, $quantidade, $estoque_id, $usuario);
                $stmt_movimentacao->execute();

                // Redirecionar para a página de registro com a mensagem de sucesso
                header("Location: registrar_uso_interno.php?produto_id=$produto_id&sucesso=1");
                exit();
            } else {
                echo "Erro ao atualizar o estoque.";
            }
        } else {
            echo "Quantidade insuficiente no estoque.";
        }
    } else {
        echo "Produto não encontrado no estoque.";
    }

    // Fechar as consultas preparadas
    $stmt_verificar->close();
    $stmt_atualizar->close();
    $stmt_movimentacao->close();
} else {
    echo "Método de requisição inválido.";
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
