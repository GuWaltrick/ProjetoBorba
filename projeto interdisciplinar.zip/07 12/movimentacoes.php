<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
require_once 'conexao.php';

// Filtro de movimentações
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'todas';
$busca_produto = isset($_GET['produto']) ? trim($_GET['produto']) : '';
$busca_lote = isset($_GET['lote']) ? trim($_GET['lote']) : '';

// Base SQL
$sql_base = "SELECT m.data_movimentacao, p.id AS produto_id, p.nome, m.quantidade, m.usuario, m.tipo, m.motivo, l.numero_lote, l.data_validade 
             FROM movimentacoes m 
             JOIN produtos p ON m.produto_id = p.id 
             LEFT JOIN lotes l ON m.lote_id = l.id";

// Aplica filtro de movimentação e busca
$where_conditions = [];
$params = [];
$bind_types = '';

// Filtros do tipo de movimentação
if ($filtro === 'entrada') {
    $where_conditions[] = "m.tipo = 'entrada'";
} elseif ($filtro === 'saida') {
    $where_conditions[] = "m.tipo = 'saida'";
} elseif ($filtro === 'uso_interno') {
    $where_conditions[] = "m.tipo = 'saida' AND m.motivo = 'Uso Interno'";
} elseif ($filtro === 'vencidos') {
    $where_conditions[] = "l.data_validade < CURDATE()";
}

// Filtros de busca por produto e lote
if (!empty($busca_produto)) {
    $where_conditions[] = "(p.nome LIKE ? OR p.id = ?)";
    $params[] = "%" . $busca_produto . "%";
    $params[] = $busca_produto;
    $bind_types .= 'si';
}

if (!empty($busca_lote)) {
    $where_conditions[] = "l.numero_lote LIKE ?";
    $params[] = "%" . $busca_lote . "%";
    $bind_types .= 's';
}

// Construir a cláusula WHERE
$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
$sql = "$sql_base $where_clause";

// Prepara a consulta
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}

// Liga os parâmetros
if (!empty($params)) {
    $stmt->bind_param($bind_types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$movimentacoes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movimentações</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <style>
        .vencido {
            color: #fff;
            background-color: #dc3545;
        }
        .btn-orange {
            background-color: #fd7e14;
            color: #fff;
        }
        .btn-orange:hover {
            background-color: #e76709;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Movimentações</h1>

        <!-- Campo de busca -->
        <form method="GET" action="" class="d-flex mb-4">
            <input type="text" name="produto" value="<?= htmlspecialchars($busca_produto) ?>" class="form-control me-2" placeholder="Buscar por nome ou ID do produto">
            <input type="text" name="lote" value="<?= htmlspecialchars($busca_lote) ?>" class="form-control me-2" placeholder="Buscar por número do lote">
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>

        <!-- Filtros -->
        <div class="mb-4 text-center">
            <a href="movimentacoes.php?filtro=todas&produto=<?= urlencode($busca_produto) ?>&lote=<?= urlencode($busca_lote) ?>"
               class="btn btn-primary <?= $filtro === 'todas' ? 'active' : '' ?>">Todas</a>
            <a href="movimentacoes.php?filtro=entrada&produto=<?= urlencode($busca_produto) ?>&lote=<?= urlencode($busca_lote) ?>"
               class="btn btn-success <?= $filtro === 'entrada' ? 'active' : '' ?>">Entradas</a>
            <a href="movimentacoes.php?filtro=saida&produto=<?= urlencode($busca_produto) ?>&lote=<?= urlencode($busca_lote) ?>"
               class="btn btn-warning <?= $filtro === 'saida' ? 'active' : '' ?>">Saídas</a>
            <a href="movimentacoes.php?filtro=uso_interno&produto=<?= urlencode($busca_produto) ?>&lote=<?= urlencode($busca_lote) ?>"
               class="btn btn-orange <?= $filtro === 'uso_interno' ? 'active' : '' ?>">Uso Interno</a>
            <a href="movimentacoes.php?filtro=vencidos&produto=<?= urlencode($busca_produto) ?>&lote=<?= urlencode($busca_lote) ?>"
               class="btn btn-danger <?= $filtro === 'vencidos' ? 'active' : '' ?>">Vencidos</a>
        </div>

        <!-- Tabela de Movimentações -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>ID do Produto</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Usuário</th>
                    <th>Tipo</th>
                    <th>Motivo</th>
                    <th>Número do Lote</th>
                    <th>Validade</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($movimentacoes)): ?>
                    <?php foreach ($movimentacoes as $mov): ?>
                        <tr class="<?= isset($mov['data_validade']) && $mov['data_validade'] < date('Y-m-d') ? 'vencido' : '' ?>">
                            <td><?= htmlspecialchars($mov['data_movimentacao']) ?></td>
                            <td><?= htmlspecialchars($mov['produto_id']) ?></td>
                            <td><?= htmlspecialchars($mov['nome']) ?></td>
                            <td><?= htmlspecialchars($mov['quantidade']) ?></td>
                            <td><?= htmlspecialchars($mov['usuario']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($mov['tipo'])) ?></td>
                            <td><?= htmlspecialchars($mov['motivo']) ?></td>
                            <td><?= htmlspecialchars($mov['numero_lote']) ?? 'N/A' ?></td>
                            <td><?= htmlspecialchars($mov['data_validade']) ?? 'N/A' ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center">Nenhuma movimentação encontrada.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
